import { useEffect, useMemo, useState } from "react";
import { BookOpen, ChevronLeft, Eye, Swords } from "lucide-react";
import { blip, unlockAudio } from "@/game/audio";
import { MAX_LEVEL, applyXp, enemyLevelFor, makeCombatant, xpReward, xpToNext } from "@/game/battle";
import { familyLabel, matchup } from "@/game/elements";
import {
  BONUS,
  RACE_DON,
  eyeById,
  eyes,
  lands,
  mods,
  nextEye,
  poolFor,
  races,
  rivalFor,
  startingEye,
  tierName,
} from "@/game/logic";
import { describeEffects, movesetFor } from "@/game/moves";
import { chapterFor } from "@/game/story";
import type { Eye as EyeData, Loadout, Phase } from "@/game/types";
import { Battle, type BattleSetup } from "./Battle";
import { EyeGlyph } from "./EyeGlyph";

const KEY = "koryu-ojos-v1";

type Save = {
  phase: Phase;
  codexReturn: Phase;
  name: string;
  raceId: string | null;
  eyeId: string | null;
  unlocked: string[];
  loadout: Loadout;
  landIndex: number;
  fightIndex: number;
  resonancia: number;
  wins: number;
  losses: number;
  defeated: string[];
  seen: string[];
  pendingAwaken: string | null;
  level: number;
  xp: number;
};

const EMPTY_LOADOUT: Loadout = { rune: null, mark: null, scar: null, tattoo: null };

const BLANK: Save = {
  phase: "title",
  codexReturn: "title",
  name: "",
  raceId: null,
  eyeId: null,
  unlocked: [],
  loadout: EMPTY_LOADOUT,
  landIndex: 0,
  fightIndex: 0,
  resonancia: 0,
  wins: 0,
  losses: 0,
  defeated: [],
  seen: [],
  pendingAwaken: null,
  level: 1,
  xp: 0,
};

function bearerName(eye: EyeData): string {
  const raw = eye.famous.replace(/\(.*?\)/g, "").split(/[,.—–]/)[0]?.trim() ?? "";
  if (raw.length > 3 && raw.length < 42) return raw;
  const clan = eye.clan.split("/")[0]?.trim() ?? "Rival";
  return clan.slice(0, 40);
}

function buildSetup(save: Save): BattleSetup {
  const eye = eyeById(save.eyeId ?? "") ?? eyes[0]!;
  const land = lands[Math.min(save.landIndex, lands.length - 1)]!;
  const chapter = chapterFor(land.id);
  const rivalEye = rivalFor({
    landId: land.id,
    fightIndex: save.fightIndex,
    playerTier: eye.tier,
    exclude: [...save.defeated, eye.id],
    salt: save.wins + save.landIndex * 5 + 3,
  });
  const fronteras = land.id === "fronteras-libres";
  const boss = save.fightIndex === 2;
  const finale = land.id === "hibridaciones-prohibidas" && boss;
  const enemyLevel = enemyLevelFor(save.landIndex, save.fightIndex);
  const you = makeCombatant({ name: save.name || "Sin nombre", eye, level: save.level, loadout: save.loadout, raceId: save.raceId });
  const foe = makeCombatant({
    name: bearerName(rivalEye),
    eye: rivalEye,
    level: enemyLevel,
    wild: fronteras,
    foe: true,
    boss,
    outMul: finale ? 1.08 : fronteras ? 1.25 : 1,
  });
  const mu = matchup(eye.family, rivalEye.family);
  const back = matchup(rivalEye.family, eye.family);
  const note = fronteras
    ? "Este ojo es chafa, pero la frontera lo hace resonar por encima de su rango."
    : mu.kind === "super"
      ? `Tu ${familyLabel(eye.family)} tiene ventaja sobre su ${familyLabel(rivalEye.family)}. Usa técnicas de tu elemento.`
      : back.kind === "super"
        ? `Cuidado: su ${familyLabel(rivalEye.family)} vence a tu ${familyLabel(eye.family)}. Aguanta y busca otro ángulo.`
        : `${familyLabel(eye.family)} contra ${familyLabel(rivalEye.family)}: naturalezas parejas.`;
  const xpWin = xpReward(enemyLevel, save.level, boss);
  return {
    you,
    foe,
    landId: land.id,
    landName: land.name.split("(")[0]?.trim() ?? land.name,
    fightIndex: save.fightIndex,
    boss,
    intro: [
      save.fightIndex === 0 ? `${chapter.title}. ${chapter.duels[0]}` : chapter.duels[save.fightIndex]!,
      `${bearerName(rivalEye)} sostiene ${rivalEye.name} (Nv. ${enemyLevel}).`,
      note,
    ],
    outro: chapter.outro,
    seed: save.wins * 7919 + save.losses * 131 + save.landIndex * 17 + save.fightIndex * 3 + 1,
    xpWin,
    xpLose: Math.round(xpWin * 0.4),
    level: save.level,
    xp: save.xp,
  };
}

function StatLine({ label, value, tone }: { label: string; value: number; tone: string }) {
  return (
    <div>
      <div className="mb-1 flex justify-between text-sm text-muted">
        <span>{label}</span>
        <span className="font-semibold text-fg">{value}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-bg">
        <div className={`h-full ${tone}`} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
      </div>
    </div>
  );
}

const btn = "inline-flex min-h-12 items-center justify-center gap-2 rounded-xl px-4 py-3 text-center font-semibold transition-colors";
const btnPrimary = `${btn} bg-primary text-on-primary hover:brightness-110`;
const btnGhost = `${btn} border border-line bg-raised text-fg hover:border-gold`;

export function KoryuGame() {
  const [save, setSave] = useState<Save>(BLANK);
  const [ready, setReady] = useState(false);
  const [racePick, setRacePick] = useState(races[0]!.id);
  const [draftName, setDraftName] = useState("");
  const [setup, setSetup] = useState<BattleSetup | null>(null);
  const [battleKey, setBattleKey] = useState(0);
  const [codexId, setCodexId] = useState(eyes[0]!.id);
  const [query, setQuery] = useState("");
  const [familyFilter, setFamilyFilter] = useState<string | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<Save>;
        if (parsed.eyeId && eyeById(parsed.eyeId)) {
          const phase = parsed.phase === "duel" ? "map" : (parsed.phase ?? "map");
          setSave({
            ...BLANK,
            ...parsed,
            phase,
            loadout: { ...EMPTY_LOADOUT, ...(parsed.loadout ?? {}) },
            unlocked: parsed.unlocked ?? [parsed.eyeId],
            defeated: parsed.defeated ?? [],
            seen: parsed.seen ?? [],
            level: Math.max(1, Math.min(MAX_LEVEL, parsed.level ?? 1 + (parsed.wins ?? 0))),
            xp: parsed.xp ?? 0,
          });
          if (parsed.raceId) setRacePick(parsed.raceId);
          if (parsed.name) setDraftName(parsed.name);
        }
      }
    } catch {
      /* archivo corrupto: se empieza de cero */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(KEY, JSON.stringify(save));
  }, [save, ready]);

  useEffect(() => {
    if (save.phase === "duel" && !setup && save.eyeId) setSetup(buildSetup(save));
    if (save.phase !== "duel" && setup) setSetup(null);
    // duel identity is owned here; including it would loop.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [save.phase, save.eyeId, save.fightIndex, save.landIndex]);

  const openCodex = (back: Phase) => {
    unlockAudio();
    blip("ui");
    setSave((s) => ({ ...s, phase: "codex", codexReturn: back }));
  };

  const finishWin = () => {
    const eye = eyeById(save.eyeId ?? "");
    const gained = 10 + save.landIndex * 4 + save.fightIndex * 3;
    const rivalId = setup?.foe.eye.id;
    const xpWin = setup?.xpWin ?? 0;
    setSave((s) => {
      const defeated = rivalId && !s.defeated.includes(rivalId) ? [...s.defeated, rivalId] : s.defeated;
      const seen = rivalId && !s.seen.includes(rivalId) ? [...s.seen, rivalId] : s.seen;
      const lastFight = s.fightIndex >= 2;
      const nextLand = lastFight ? s.landIndex + 1 : s.landIndex;
      const awaken = lastFight && s.raceId && s.eyeId ? nextEye(s.raceId, s.eyeId) : null;
      const done = nextLand >= lands.length;
      const lv = applyXp(s.level, s.xp, xpWin);
      return {
        ...s,
        defeated,
        seen,
        level: lv.level,
        xp: lv.xp,
        resonancia: s.resonancia + gained,
        wins: s.wins + 1,
        fightIndex: lastFight ? 0 : s.fightIndex + 1,
        landIndex: done ? lands.length : nextLand,
        pendingAwaken: awaken?.id ?? null,
        phase: done ? "ending" : awaken ? "awaken" : lastFight ? "map" : "duel",
      };
    });
    setSetup(null);
    setBattleKey((k) => k + 1);
    if (eye) blip("win");
  };

  const finishLose = (next: "retry" | "map") => {
    const xpLose = setup?.xpLose ?? 0;
    const lv = applyXp(save.level, save.xp, xpLose);
    const nextSave: Save = { ...save, losses: save.losses + 1, level: lv.level, xp: lv.xp, phase: next === "map" ? "map" : "duel" };
    setSave(nextSave);
    if (next === "retry") {
      setSetup(buildSetup(nextSave));
      setBattleKey((k) => k + 1);
    } else setSetup(null);
    blip("ui");
  };

  const hasRun = Boolean(save.eyeId && save.raceId);

  return (
    <div className="min-h-screen overflow-x-hidden bg-bg text-fg" onPointerDown={unlockAudio}>
      <div className="mx-auto flex min-h-screen w-full max-w-5xl flex-col px-4 py-5 sm:px-6">
        <header className="mb-5 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="font-display text-xs tracking-[0.28em] text-gold">KŌRYU</p>
            <h1 className="truncate font-display text-xl font-extrabold sm:text-2xl">Ojos del Kōryu</h1>
          </div>
          <div className="flex gap-2">
            {save.phase !== "title" && save.phase !== "duel" && (
              <button type="button" className={btnGhost} onClick={() => openCodex(save.phase)}>
                <BookOpen className="size-4" aria-hidden />
                Archivo
              </button>
            )}
          </div>
        </header>

        {save.phase === "title" && (
          <Title
            ready={ready}
            hasRun={hasRun}
            name={save.name}
            onContinue={() => {
              blip("ui");
              setSave((s) => ({ ...s, phase: s.pendingAwaken ? "awaken" : "map" }));
            }}
            onNew={() => {
              blip("ui");
              setRacePick(races[2]!.id);
              setSave((s) => ({ ...BLANK, phase: "lineage" }));
            }}
            onCodex={() => openCodex("title")}
          />
        )}

        {save.phase === "lineage" && (
          <Lineage
            raceId={racePick}
            onPick={setRacePick}
            onBack={() => setSave((s) => ({ ...s, phase: "title" }))}
            onNext={() => {
              blip("ui");
              const race = races.find((r) => r.id === racePick)!;
              setDraftName(save.name || "");
              setSave((s) => ({
                ...s,
                phase: "oath",
                raceId: race.id,
                loadout: {
                  rune: race.mods.runeId ?? null,
                  mark: race.mods.markId ?? null,
                  scar: race.mods.scarId ?? null,
                  tattoo: race.mods.tattooId ?? null,
                },
              }));
            }}
          />
        )}

        {save.phase === "oath" && save.raceId && (
          <Oath
            raceId={save.raceId}
            name={draftName}
            onName={setDraftName}
            onBack={() => setSave((s) => ({ ...s, phase: "lineage" }))}
            onStart={() => {
              const eye = startingEye(save.raceId!);
              const name = draftName.trim().slice(0, 24) || "Sin nombre";
              blip("win");
              setSave((s) => ({
                ...s,
                phase: "map",
                name,
                eyeId: eye.id,
                unlocked: [eye.id],
                seen: [eye.id],
                landIndex: 0,
                fightIndex: 0,
                resonancia: 0,
                wins: 0,
                losses: 0,
                defeated: [],
                pendingAwaken: null,
              }));
            }}
          />
        )}

        {save.phase === "map" && hasRun && (
          <WorldMap
            save={save}
            onFight={() => {
              blip("ui");
              const eye = eyeById(save.eyeId!);
              setSave((s) => ({
                ...s,
                phase: "duel",
                seen: eye && !s.seen.includes(eye.id) ? [...s.seen, eye.id] : s.seen,
              }));
              setSetup(null);
            }}
            onArmory={() => setSave((s) => ({ ...s, phase: "armory" }))}
            onAbandon={() => {
              localStorage.removeItem(KEY);
              setSave(BLANK);
              setSetup(null);
            }}
          />
        )}

        {save.phase === "armory" && (
          <Armory
            loadout={save.loadout}
            onChange={(loadout) => setSave((s) => ({ ...s, loadout }))}
            onBack={() => setSave((s) => ({ ...s, phase: "map" }))}
          />
        )}

        {save.phase === "duel" && setup && <Battle key={battleKey} setup={setup} onWin={finishWin} onLose={finishLose} />}

        {save.phase === "awaken" && save.pendingAwaken && (
          <Awaken
            fromId={save.eyeId}
            toId={save.pendingAwaken}
            onAccept={() => {
              const id = save.pendingAwaken!;
              blip("win");
              setSave((s) => ({
                ...s,
                eyeId: id,
                pendingAwaken: null,
                phase: "map",
                unlocked: s.unlocked.includes(id) ? s.unlocked : [...s.unlocked, id],
                seen: s.seen.includes(id) ? s.seen : [...s.seen, id],
              }));
            }}
          />
        )}

        {save.phase === "ending" && <Ending save={save} onCodex={() => openCodex("ending")} onAgain={() => setSave({ ...BLANK, phase: "lineage" })} />}

        {save.phase === "codex" && (
          <Codex
            query={query}
            onQuery={setQuery}
            family={familyFilter}
            onFamily={setFamilyFilter}
            selected={codexId}
            onSelect={setCodexId}
            seen={save.seen}
            onBack={() => setSave((s) => ({ ...s, phase: s.codexReturn === "codex" ? "title" : s.codexReturn }))}
          />
        )}
      </div>
    </div>
  );
}

function Title({
  ready,
  hasRun,
  name,
  onContinue,
  onNew,
  onCodex,
}: {
  ready: boolean;
  hasRun: boolean;
  name: string;
  onContinue: () => void;
  onNew: () => void;
  onCodex: () => void;
}) {
  const sig = eyeById("kagetsugan") ?? eyes[0]!;
  return (
    <section className="grid flex-1 items-center gap-8 lg:grid-cols-[1.1fr_0.9fr]">
      <div>
        <p className="mb-3 font-display text-5xl text-gold/80 sm:text-6xl" aria-hidden>
          光竜
        </p>
        <h2 className="font-display text-4xl font-extrabold leading-tight sm:text-5xl">
          El mundo mira con ojos que no son humanos.
        </h2>
        <p className="mt-4 max-w-xl text-lg leading-relaxed text-muted">
          Ciento sesenta y seis dōjutsu, diez linajes y ocho países. Cruza el archivo del Kōryu en duelo: cada mirada tiene
          origen, precio y un jutsu que no debería pronunciarse.
        </p>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          {ready && hasRun && (
            <button type="button" className={btnPrimary} onClick={onContinue}>
              <Swords className="size-4" aria-hidden />
              Continuar como {name || "peregrino"}
            </button>
          )}
          <button type="button" className={hasRun ? btnGhost : btnPrimary} onClick={onNew}>
            {hasRun ? "Empezar de nuevo" : "Iniciar peregrinaje"}
          </button>
          <button type="button" className={btnGhost} onClick={onCodex}>
            <BookOpen className="size-4" aria-hidden />
            Abrir el archivo
          </button>
        </div>
      </div>
      <div className="flex flex-col items-center rounded-2xl border border-line bg-surface px-6 py-8">
        <EyeGlyph eye={sig} size={220} spin />
        <p className="mt-4 text-center font-display text-lg">{sig.name}</p>
        <p className="mt-1 text-center text-sm text-muted">{sig.kanji}</p>
      </div>
    </section>
  );
}

function Lineage({
  raceId,
  onPick,
  onBack,
  onNext,
}: {
  raceId: string;
  onPick: (id: string) => void;
  onBack: () => void;
  onNext: () => void;
}) {
  const race = races.find((r) => r.id === raceId) ?? races[0]!;
  const don = RACE_DON[race.id];
  const start = startingEye(race.id);
  return (
    <section className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <div className="flex gap-2 overflow-x-auto pb-1 lg:flex-col lg:overflow-visible">
        {races.map((r) => {
          const on = r.id === race.id;
          return (
            <button
              key={r.id}
              type="button"
              onClick={() => onPick(r.id)}
              className={`min-w-56 shrink-0 rounded-xl border px-3 py-3 text-left lg:min-w-0 ${on ? "border-gold bg-raised" : "border-line bg-surface"}`}
            >
              <span className="block font-display text-lg text-gold">{r.kanji || "眼"}</span>
              <span className="mt-1 block text-sm font-semibold leading-snug">{r.name}</span>
            </button>
          );
        })}
      </div>
      <article className="rounded-2xl border border-line bg-surface p-5 sm:p-6">
        <p className="text-sm font-semibold tracking-wide text-gold">{race.title}</p>
        <h2 className="mt-1 font-display text-2xl font-extrabold">{race.name}</h2>
        <p className="mt-1 text-sm text-muted">{race.jp}</p>
        <p className="mt-4 leading-relaxed text-muted">{race.philosophy}</p>
        <p className="mt-3 leading-relaxed">{race.culture}</p>
        <dl className="mt-4 grid gap-3 sm:grid-cols-2">
          <div className="rounded-xl bg-raised p-3">
            <dt className="text-xs font-semibold tracking-wide text-gold">Chakra</dt>
            <dd className="mt-1 text-sm">{race.chakraType}</dd>
          </div>
          <div className="rounded-xl bg-raised p-3">
            <dt className="text-xs font-semibold tracking-wide text-gold">Don del linaje</dt>
            <dd className="mt-1 text-sm">{don?.label}</dd>
          </div>
        </dl>
        <p className="mt-3 text-sm text-muted">
          Elementos: {race.elements.join(" · ")}. {race.resistance}
        </p>
        <div className="mt-4 flex items-center gap-4">
          <EyeGlyph eye={start} size={96} />
          <div>
            <p className="text-xs font-semibold tracking-wide text-gold">Ojo de partida · {tierName(start.tier)}</p>
            <p className="font-semibold">{start.name}</p>
            <p className="text-sm text-muted">{start.element}</p>
          </div>
        </div>
        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          <button type="button" className={btnGhost} onClick={onBack}>
            <ChevronLeft className="size-4" />
            Volver
          </button>
          <button type="button" className={btnPrimary} onClick={onNext}>
            Jurar este linaje
          </button>
        </div>
      </article>
    </section>
  );
}

function Oath({
  raceId,
  name,
  onName,
  onBack,
  onStart,
}: {
  raceId: string;
  name: string;
  onName: (v: string) => void;
  onBack: () => void;
  onStart: () => void;
}) {
  const race = races.find((r) => r.id === raceId)!;
  const start = startingEye(raceId);
  const pool = poolFor(raceId);
  return (
    <section className="mx-auto grid w-full max-w-3xl gap-5">
      <div className="rounded-2xl border border-line bg-surface p-5 sm:flex sm:gap-6">
        <div className="flex justify-center">
          <EyeGlyph eye={start} size={180} spin />
        </div>
        <div className="mt-4 min-w-0 sm:mt-0">
          <p className="text-sm text-gold">{start.kanji}</p>
          <h2 className="font-display text-2xl font-extrabold">{start.name}</h2>
          <p className="mt-1 text-sm text-muted">
            {start.rank} · {familyLabel(start.family)} · {race.name}
          </p>
          <p className="mt-3 text-sm leading-relaxed">{start.origin}</p>
          <p className="mt-2 text-sm leading-relaxed text-muted">Despertar: {start.awakening}</p>
        </div>
      </div>
      <label className="block">
        <span className="mb-2 block text-sm font-semibold">Nombre del portador</span>
        <input
          value={name}
          onChange={(e) => onName(e.target.value)}
          maxLength={24}
          placeholder="Cómo te recordará el archivo"
          className="min-h-12 w-full rounded-xl border border-line bg-raised px-4 text-fg outline-none focus:border-gold"
        />
      </label>
      <div>
        <p className="mb-2 text-sm font-semibold text-muted">Camino de despertar de este linaje</p>
        <div className="flex gap-3 overflow-x-auto pb-2">
          {pool.map((eye) => (
            <div
              key={eye.id}
              className={`w-28 shrink-0 rounded-xl border p-2 text-center ${eye.id === start.id ? "border-gold bg-raised" : "border-line opacity-70"}`}
            >
              <div className="flex justify-center">
                <EyeGlyph eye={eye} size={72} />
              </div>
              <p className="mt-1 text-xs font-semibold text-gold">{tierName(eye.tier)}</p>
              <p className="line-clamp-2 text-xs">{eye.name}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="flex flex-col gap-2 sm:flex-row">
        <button type="button" className={btnGhost} onClick={onBack}>
          <ChevronLeft className="size-4" />
          Linaje
        </button>
        <button type="button" className={btnPrimary} onClick={onStart}>
          <Eye className="size-4" />
          Abrir los ojos
        </button>
      </div>
    </section>
  );
}

function WorldMap({
  save,
  onFight,
  onArmory,
  onAbandon,
}: {
  save: Save;
  onFight: () => void;
  onArmory: () => void;
  onAbandon: () => void;
}) {
  const eye = eyeById(save.eyeId ?? "")!;
  const race = races.find((r) => r.id === save.raceId);
  const land = lands[save.landIndex];
  return (
    <section className="grid gap-4 lg:grid-cols-[1fr_300px]">
      <div className="grid gap-3">
        {lands.map((item, i) => {
          const state = i < save.landIndex ? "hecho" : i === save.landIndex ? "ahora" : "sellado";
          return (
            <article
              key={item.id}
              className={`rounded-2xl border p-4 ${state === "ahora" ? "border-gold bg-raised" : "border-line bg-surface"} ${state === "sellado" ? "opacity-55" : ""}`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-xs font-semibold tracking-wide text-gold">
                    {state === "hecho" ? "Cruzado" : state === "ahora" ? "En curso" : "Aún cerrado"} · {item.element}
                  </p>
                  <h2 className="font-display text-xl font-extrabold">{item.name}</h2>
                  <p className="text-sm text-muted">{item.sub}</p>
                </div>
                {state === "ahora" && (
                  <p className="shrink-0 text-sm font-semibold text-gold">
                    Duelo {save.fightIndex + 1}/3
                  </p>
                )}
              </div>
              {state === "ahora" && (
                <div className="mt-3 space-y-3 text-sm leading-relaxed">
                  <div className="rounded-xl border border-gold/60 bg-bg p-3">
                    <p className="font-display text-gold">{chapterFor(item.id).title}</p>
                    <p className="mt-1">{chapterFor(item.id).intro}</p>
                  </div>
                  <p>{item.description}</p>
                  <p className="text-muted">{item.treaty}</p>
                  <div className="grid gap-2">
                    {item.clans.map((c) => (
                      <details key={c.id} className="rounded-xl bg-bg px-3 py-2">
                        <summary className="cursor-pointer font-semibold">
                          {c.name} <span className="text-gold">{c.kanji}</span>
                        </summary>
                        <p className="mt-2 text-muted">{c.lore}</p>
                        <p className="mt-1 text-muted">
                          {c.settlement}. {c.status}. {c.relation}
                        </p>
                      </details>
                    ))}
                  </div>
                </div>
              )}
            </article>
          );
        })}
      </div>
      <aside className="h-fit rounded-2xl border border-line bg-surface p-4 lg:sticky lg:top-4">
        <div className="flex items-center gap-3">
          <EyeGlyph eye={eye} size={84} spin />
          <div className="min-w-0">
            <p className="truncate text-xs text-gold">{race?.kanji}</p>
            <p className="truncate font-semibold">{save.name}</p>
            <p className="text-sm text-muted">{tierName(eye.tier)}</p>
          </div>
        </div>
        <p className="mt-3 text-sm font-semibold">{eye.name}</p>
        <p className="text-sm text-muted">
          Resonancia {save.resonancia} · {save.wins} victorias · {save.seen.length}/166 ojos vistos
        </p>
        <div className="mt-3">
          <div className="flex items-baseline justify-between text-sm">
            <span className="font-semibold text-gold">Nivel {save.level}</span>
            <span className="text-xs text-muted">{save.level >= MAX_LEVEL ? "máximo" : `${save.xp}/${xpToNext(save.level)} EXP`}</span>
          </div>
          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-bg">
            <div className="h-full bg-sky-400" style={{ width: `${save.level >= MAX_LEVEL ? 100 : Math.min(100, (save.xp / xpToNext(save.level)) * 100)}%` }} />
          </div>
        </div>
        <details className="mt-3 rounded-xl bg-bg px-3 py-2 text-sm">
          <summary className="cursor-pointer font-semibold">Técnicas de este ojo</summary>
          <ul className="mt-2 space-y-2">
            {movesetFor(eye).map((m) => (
              <li key={m.id} className={m.unlock > save.level ? "opacity-50" : undefined}>
                <p className="font-semibold">
                  {m.name} <span className="text-xs font-normal text-gold">{familyLabel(m.family)}</span>
                </p>
                <p className="text-xs text-muted">
                  {m.unlock > save.level ? `Se aprende en el nivel ${m.unlock}. ` : ""}
                  {m.power > 0 ? `Poder ${m.power}, ` : ""}
                  {m.cost} chakra{describeEffects(m).length ? ` · ${describeEffects(m).join(", ")}` : ""}
                </p>
                <p className="text-xs text-muted">{m.blurb}</p>
              </li>
            ))}
          </ul>
        </details>
        {land && (
          <button type="button" className={`${btnPrimary} mt-4 w-full`} onClick={onFight}>
            <Swords className="size-4" />
            Duelo en {land.name.split("(")[0]?.trim()}
          </button>
        )}
        <button type="button" className={`${btnGhost} mt-2 w-full`} onClick={onArmory}>
          Runas, marcas y cicatrices
        </button>
        <button type="button" className="mt-3 text-sm text-muted underline-offset-2 hover:underline" onClick={onAbandon}>
          Abandonar peregrinaje
        </button>
      </aside>
    </section>
  );
}

function Armory({ loadout, onChange, onBack }: { loadout: Loadout; onChange: (l: Loadout) => void; onBack: () => void }) {
  const groups = [
    ["rune", "Runas"],
    ["mark", "Marcas"],
    ["scar", "Cicatrices"],
    ["tattoo", "Tatuajes"],
  ] as const;
  return (
    <section>
      <button type="button" className={`${btnGhost} mb-4`} onClick={onBack}>
        <ChevronLeft className="size-4" />
        Volver al mapa
      </button>
      <h2 className="font-display text-2xl font-extrabold">Cuerpo escrito</h2>
      <p className="mt-1 max-w-2xl text-muted">
        Una de cada clase. No cambian el archivo del ojo: cambian cómo duele en el duelo.
      </p>
      <div className="mt-4 grid gap-4">
        {groups.map(([cat, label]) => (
          <div key={cat}>
            <h3 className="mb-2 font-display text-lg text-gold">{label}</h3>
            <div className="grid gap-2 sm:grid-cols-2">
              {mods
                .filter((m) => m.category === cat)
                .map((m) => {
                  const on = loadout[cat] === m.id;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => onChange({ ...loadout, [cat]: on ? null : m.id })}
                      className={`rounded-xl border p-3 text-left ${on ? "border-gold bg-raised" : "border-line bg-surface"}`}
                    >
                      <p className="text-xs text-gold">{m.kanji}</p>
                      <p className="font-semibold leading-snug">{m.name}</p>
                      <p className="mt-1 text-sm text-primary">{BONUS[m.id]?.blurb}</p>
                      <p className="mt-1 line-clamp-3 text-sm text-muted">{m.explanation}</p>
                    </button>
                  );
                })}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Awaken({ fromId, toId, onAccept }: { fromId: string | null; toId: string; onAccept: () => void }) {
  const from = fromId ? eyeById(fromId) : undefined;
  const to = eyeById(toId)!;
  return (
    <section className="mx-auto max-w-3xl rounded-2xl border border-gold bg-surface p-5 sm:p-8">
      <p className="text-sm font-semibold tracking-wide text-gold">Despertar</p>
      <h2 className="mt-1 font-display text-3xl font-extrabold">El país calla. El ojo pide más.</h2>
      <p className="mt-3 leading-relaxed text-muted">La condición que el archivo exige ya quedó escrita en el camino:</p>
      <p className="mt-2 text-lg leading-relaxed">{to.awakening}</p>
      <div className="mt-5 grid items-center gap-4 sm:grid-cols-[1fr_auto_1fr]">
        {from && (
          <div className="text-center">
            <div className="flex justify-center">
              <EyeGlyph eye={from} size={120} />
            </div>
            <p className="mt-2 text-sm text-muted">{from.name}</p>
          </div>
        )}
        <p className="text-center font-display text-gold">hacia</p>
        <div className="text-center">
          <div className="flex justify-center">
            <EyeGlyph eye={to} size={140} spin />
          </div>
          <p className="mt-2 font-semibold">{to.name}</p>
          <p className="text-sm text-gold">{to.kanji}</p>
        </div>
      </div>
      <p className="mt-4 text-sm leading-relaxed text-muted">{to.origin}</p>
      <div className="mt-4 rounded-xl border border-line bg-bg p-3 text-sm">
        <p className="font-semibold text-gold">Técnicas del nuevo ojo</p>
        <ul className="mt-2 space-y-1.5">
          {movesetFor(to).map((m) => (
            <li key={m.id}>
              <span className="font-semibold">{m.name}</span> <span className="text-xs text-gold">{familyLabel(m.family)}</span>
              <span className="text-xs text-muted"> · nivel {m.unlock}</span>
            </li>
          ))}
        </ul>
      </div>
      <button type="button" className={`${btnPrimary} mt-5`} onClick={onAccept}>
        Aceptar {to.name}
      </button>
    </section>
  );
}

function Ending({ save, onCodex, onAgain }: { save: Save; onCodex: () => void; onAgain: () => void }) {
  const eye = eyeById(save.eyeId ?? "");
  const race = races.find((r) => r.id === save.raceId);
  return (
    <section className="mx-auto max-w-3xl text-center">
      <p className="font-display text-5xl text-gold">光竜</p>
      <h2 className="mt-3 font-display text-4xl font-extrabold">Los ocho países te devolvieron la mirada.</h2>
      <p className="mt-4 text-lg leading-relaxed text-muted">
        {save.name}, de {race?.name}, cierra el peregrinaje con {eye?.name}. Resonancia {save.resonancia}. Ojos
        testimoniados: {save.seen.length} de 166. Victorias {save.wins}, caídas {save.losses}.
      </p>
      {eye && (
        <div className="mt-6 flex justify-center">
          <EyeGlyph eye={eye} size={200} spin />
        </div>
      )}
      <p className="mt-4 text-sm text-muted">{eye?.apex}</p>
      <div className="mt-6 flex flex-col justify-center gap-2 sm:flex-row">
        <button type="button" className={btnPrimary} onClick={onCodex}>
          <BookOpen className="size-4" />
          Leer el archivo completo
        </button>
        <button type="button" className={btnGhost} onClick={onAgain}>
          Otro linaje
        </button>
      </div>
    </section>
  );
}

function Codex({
  query,
  onQuery,
  family,
  onFamily,
  selected,
  onSelect,
  seen,
  onBack,
}: {
  query: string;
  onQuery: (v: string) => void;
  family: string | null;
  onFamily: (v: string | null) => void;
  selected: string;
  onSelect: (id: string) => void;
  seen: string[];
  onBack: () => void;
}) {
  const families = ["fire", "wind", "lightning", "earth", "water", "blood", "yin", "yang", "void"];
  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return eyes.filter((eye) => {
      if (family && eye.family !== family) return false;
      if (!q) return true;
      const blob = `${eye.name} ${eye.jp} ${eye.kanji} ${eye.clan} ${eye.element} ${eye.famous} ${eye.ability}`.toLowerCase();
      return blob.includes(q);
    });
  }, [query, family]);
  const eye = eyeById(selected) ?? list[0] ?? eyes[0]!;
  return (
    <section>
      <button type="button" className={`${btnGhost} mb-4`} onClick={onBack}>
        <ChevronLeft className="size-4" />
        Volver
      </button>
      <h2 className="font-display text-3xl font-extrabold">Archivo de los 166</h2>
      <p className="mt-1 text-muted">Origen, condición, jutsu y portador. Lo que viste en duelo queda marcado.</p>
      <input
        value={query}
        onChange={(e) => onQuery(e.target.value)}
        placeholder="Buscar clan, jutsu, portador…"
        className="mt-4 min-h-12 w-full rounded-xl border border-line bg-surface px-4 outline-none focus:border-gold"
      />
      <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
        <button type="button" className={family ? btnGhost : btnPrimary} onClick={() => onFamily(null)}>
          Todos
        </button>
        {families.map((f) => (
          <button key={f} type="button" className={`${family === f ? btnPrimary : btnGhost} shrink-0`} onClick={() => onFamily(f)}>
            {familyLabel(f)}
          </button>
        ))}
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-[280px_1fr]">
        <div className="max-h-80 overflow-y-auto rounded-xl border border-line lg:max-h-[70vh]">
          {list.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelect(item.id)}
              className={`block w-full border-b border-line px-3 py-3 text-left ${item.id === eye.id ? "bg-raised" : "bg-surface"}`}
            >
              <span className="block text-sm font-semibold">{item.name}</span>
              <span className="text-xs text-muted">
                {seen.includes(item.id) ? "Visto · " : ""}
                {tierName(item.tier)} · {familyLabel(item.family)}
              </span>
            </button>
          ))}
          {list.length === 0 && <p className="p-4 text-sm text-muted">Nada con ese nombre en el archivo.</p>}
        </div>
        <article className="rounded-2xl border border-line bg-surface p-5">
          <div className="sm:flex sm:gap-5">
            <div className="flex justify-center">
              <EyeGlyph eye={eye} size={160} spin />
            </div>
            <div className="mt-3 min-w-0 sm:mt-0">
              <p className="text-gold">{eye.kanji}</p>
              <h3 className="font-display text-2xl font-extrabold">{eye.name}</h3>
              <p className="text-sm text-muted">{eye.jp}</p>
              <p className="mt-2 text-sm">
                {eye.rank} · {eye.classification}
              </p>
              <p className="text-sm text-muted">{eye.clan}</p>
              <p className="text-sm text-muted">{eye.element}</p>
            </div>
          </div>
          <p className="mt-4 text-sm leading-relaxed">{eye.look}</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <StatLine label="Genjutsu" value={eye.stats.g} tone="bg-primary" />
            <StatLine label="Percepción" value={eye.stats.p} tone="bg-gold" />
            <StatLine label="Ninjutsu" value={eye.stats.n} tone="bg-blood" />
            <StatLine label="Alcance" value={eye.stats.r} tone="bg-fg" />
            <StatLine label="Drenaje" value={eye.stats.d} tone="bg-muted" />
          </div>
          <div className="mt-4 space-y-3 text-sm leading-relaxed">
            <p>
              <span className="font-semibold text-gold">Origen. </span>
              {eye.origin}
            </p>
            <p>
              <span className="font-semibold text-gold">Despertar. </span>
              {eye.awakening}
            </p>
            <p>
              <span className="font-semibold text-gold">Don. </span>
              {eye.ability}
            </p>
            <p>
              <span className="font-semibold text-gold">Prohibido. </span>
              {eye.apex}
            </p>
            <p>
              <span className="font-semibold text-gold">Coste. </span>
              {eye.costNote}
            </p>
            <p>
              <span className="font-semibold text-gold">Portador. </span>
              {eye.famous}
            </p>
          </div>
        </article>
      </div>
    </section>
  );
}
