import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { ChevronLeft, Eye as EyeIcon, FastForward, RotateCcw, Shield, Swords, Sparkles } from "lucide-react";
import { blip, unlockAudio } from "@/game/audio";
import {
  STATUS_LABEL,
  applyXp,
  canUse,
  costOf,
  describeChoice,
  isKnown,
  levelMul,
  mulberry,
  playTurn,
  snapshot,
  startBattle,
  xpToNext,
  type Battle as BattleState,
} from "@/game/battle";
import { CHART_LINES, familyColor, familyLabel, matchup } from "@/game/elements";
import { describeEffects } from "@/game/moves";
import type { Beat, Choice, Combatant, Move, Side, Snap, Status } from "@/game/types";
import { tierName } from "@/game/logic";
import { EyeGlyph } from "./EyeGlyph";

export type BattleSetup = {
  you: Combatant;
  foe: Combatant;
  landId: string;
  landName: string;
  fightIndex: number;
  boss: boolean;
  intro: string[];
  outro: string;
  seed: number;
  xpWin: number;
  xpLose: number;
  level: number;
  xp: number;
};

const LAND_BG: Record<string, [string, string]> = {
  fuego: ["#4a1a0a", "#150805"],
  viento: ["#4a3a18", "#17110a"],
  agua: ["#0d3a4d", "#07131a"],
  rayo: ["#1c2250", "#0a0c1c"],
  tierra: ["#4a3118", "#150e08"],
  "abismo-celestial": ["#2a1250", "#0b0618"],
  "fronteras-libres": ["#4a3a22", "#16110a"],
  "hibridaciones-prohibidas": ["#4a0f1c", "#12050a"],
};

const STATUS_COLOR: Record<Status, string> = {
  burn: "#f97316",
  bleed: "#ef4444",
  poison: "#84cc16",
  stun: "#facc15",
  slow: "#38bdf8",
  blind: "#a78bfa",
};

const FX_MS: Record<string, number> = {
  orb: 820,
  whirl: 1000,
  beam: 700,
  slash: 620,
  claw: 680,
  bolt: 700,
  wave: 900,
  burst: 760,
  rain: 900,
  pillar: 820,
  pulse: 850,
  heal: 900,
  guard: 820,
  punch: 650,
  kick: 700,
};

const btn = "inline-flex min-h-12 items-center justify-center gap-2 rounded-xl px-4 py-3 text-center font-semibold transition-colors";
const btnPrimary = `${btn} bg-primary text-on-primary hover:brightness-110`;
const btnGhost = `${btn} border border-line bg-raised text-fg hover:border-gold`;

function cv(o: Record<string, string | number>): CSSProperties {
  return o as unknown as CSSProperties;
}

function hpColor(pct: number): string {
  return pct > 50 ? "#6fbf73" : pct > 22 ? "#d4b15a" : "#c0414c";
}

type Pt = { x: number; y: number };
type ActiveFx = NonNullable<Beat["fx"]> & { id: number; a: Pt; b: Pt };

function FxView({ fx }: { fx: ActiveFx }) {
  const { a, b, color, kind, family, id } = fx;
  const self = kind === "heal" || kind === "guard" || fx.from === fx.to;
  const to = self ? a : b;
  const base = { "--c": color, "--x0": `${a.x}px`, "--y0": `${a.y}px`, "--x1": `${to.x}px`, "--y1": `${to.y}px` };
  const st = cv(base);
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const dist = Math.hypot(dx, dy);
  const ang = (Math.atan2(dy, dx) * 180) / Math.PI;

  if (kind === "orb")
    return (
      <>
        <span className={`fx fx-orb fam-${family}`} style={st} />
        <span className="fx fx-ring" style={{ ...st, animationDelay: "0.44s" }} />
      </>
    );
  if (kind === "whirl")
    return (
      <>
        <span className="fx fx-whirl" style={st} />
        <span className="fx fx-whirl w2" style={st} />
        <span className="fx fx-whirl w3" style={st} />
      </>
    );
  if (kind === "beam")
    return (
      <>
        <span className="fx fx-beam-wrap" style={cv({ transform: `translate(${a.x}px, ${a.y}px) rotate(${ang}deg)` })}>
          <span className="fx-beam block" style={cv({ "--c": color, width: `${dist}px` })} />
        </span>
        <span className="fx fx-ring" style={{ ...st, animationDelay: "0.25s" }} />
      </>
    );
  if (kind === "slash")
    return (
      <>
        {[-16, 0, 16].map((o, i) => (
          <span key={i} className="fx fx-slash" style={cv({ "--c": color, "--x1": `${to.x + o * 0.6}px`, "--y1": `${to.y + o}px`, animationDelay: `${i * 0.08}s` })} />
        ))}
      </>
    );
  if (kind === "claw")
    return (
      <>
        {[-26, 0, 26].map((o, i) => (
          <span key={i} className="fx fx-claw" style={cv({ "--c": color, left: to.x + o, top: to.y, animationDelay: `${i * 0.09}s` })} />
        ))}
      </>
    );
  if (kind === "bolt") {
    const rnd = (n: number) => {
      const t = Math.sin((id + 1) * 91.7 + n * 12.9) * 43758.5453;
      return t - Math.floor(t);
    };
    const pts: string[] = [];
    const top = Math.max(-10, to.y - 260);
    const segs = 7;
    for (let i = 0; i <= segs; i++) {
      const t = i / segs;
      const x = to.x + (i === 0 || i === segs ? 0 : (rnd(i) - 0.5) * 60) + (1 - t) * 24;
      pts.push(`${x},${top + (to.y - top) * t}`);
    }
    const d = `M${pts.join(" L")}`;
    return (
      <svg className="fx-bolt-svg" aria-hidden>
        <path d={d} className="fx-bolt-path" pathLength={1} stroke={color} strokeWidth={14} opacity={0.5} style={{ filter: `blur(4px) drop-shadow(0 0 10px ${color})` }} />
        <path d={d} className="fx-bolt-path" pathLength={1} stroke="#fff" strokeWidth={4} />
      </svg>
    );
  }
  if (kind === "wave")
    return <span className="fx fx-wave" style={cv({ "--c": color, "--x0": `${a.x}px`, "--x1": `${to.x}px`, "--y1": `${to.y}px` })} />;
  if (kind === "burst")
    return (
      <>
        <span className="fx fx-burst" style={st} />
        {Array.from({ length: 8 }, (_, i) => (
          <span key={i} className="fx fx-spike" style={cv({ "--c": color, "--x1": `${to.x}px`, "--y1": `${to.y}px`, "--a": `${i * 45}deg` })} />
        ))}
      </>
    );
  if (kind === "rain")
    return (
      <>
        {Array.from({ length: 16 }, (_, i) => (
          <span key={i} className="fx fx-drop" style={cv({ "--c": color, "--y1": `${to.y}px`, "--dx": `${to.x + ((i * 37) % 120) - 60}px`, animationDelay: `${(i % 8) * 0.06}s` })} />
        ))}
        <span className="fx fx-ring" style={{ ...st, animationDelay: "0.5s" }} />
      </>
    );
  if (kind === "pillar")
    return (
      <>
        <span className="fx fx-pillar" style={st} />
        <span className="fx fx-pillar" style={{ ...st, transform: "none", animationDelay: "0.12s", width: 54, left: -42 }} />
      </>
    );
  if (kind === "pulse")
    return (
      <>
        {[0, 0.18, 0.36].map((d) => (
          <span key={d} className="fx fx-pulse" style={{ ...st, animationDelay: `${d}s` }} />
        ))}
      </>
    );
  if (kind === "heal")
    return (
      <>
        {Array.from({ length: 10 }, (_, i) => (
          <span key={i} className="fx fx-spark" style={cv({ "--c": color === "#e5e7eb" ? "#86efac" : color, "--y1": `${a.y + 30}px`, "--dx": `${a.x + ((i * 29) % 90) - 45}px`, animationDelay: `${i * 0.06}s` })} />
        ))}
      </>
    );
  if (kind === "guard") return <span className="fx fx-shield" style={st} />;
  if (kind === "kick")
    return (
      <>
        <span className="fx fx-crescent" style={cv({ left: to.x, top: to.y })} />
        <span className="fx fx-star" style={st} />
      </>
    );
  return <span className="fx fx-star" style={st} />;
}

function Plate({ c, snap, side, xp }: { c: Combatant; snap: Snap; side: Side; xp?: { level: number; xp: number } }) {
  const pct = Math.max(0, Math.min(100, (snap.hp / c.hpMax) * 100));
  const cpct = Math.max(0, Math.min(100, (snap.chakra / c.chakraMax) * 100));
  const sts = Object.keys(snap.status) as Status[];
  return (
    <div className="rounded-xl border border-line bg-bg/85 p-2.5 backdrop-blur-sm sm:p-3">
      <div className="flex items-baseline justify-between gap-2">
        <p className="truncate font-display text-sm font-extrabold sm:text-base">{c.name}</p>
        <p className="shrink-0 text-xs font-semibold text-gold">Nv. {c.level}</p>
      </div>
      <p className="truncate text-[11px] text-muted">
        {tierName(c.eye.tier)} · {familyLabel(c.family)}
      </p>
      <div className="mt-1.5 flex items-center gap-2">
        <span className="text-[10px] font-bold tracking-wider text-muted">VIDA</span>
        <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-black/60">
          <div className="bt-hpbar h-full rounded-full" style={{ width: `${pct}%`, backgroundColor: hpColor(pct) }} />
        </div>
      </div>
      {side === "you" ? (
        <>
          <p className="mt-0.5 text-right text-xs tabular-nums text-muted">
            {snap.hp}/{c.hpMax}
          </p>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold tracking-wider text-muted">CHAK</span>
            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-black/60">
              <div className="bt-hpbar h-full rounded-full bg-gold" style={{ width: `${cpct}%` }} />
            </div>
            <span className="w-9 text-right text-[11px] tabular-nums text-muted">{snap.chakra}</span>
          </div>
          {xp && (
            <div className="mt-1 flex items-center gap-2">
              <span className="text-[10px] font-bold tracking-wider text-muted">EXP</span>
              <div className="h-1 flex-1 overflow-hidden rounded-full bg-black/60">
                <div className="h-full rounded-full bg-sky-400" style={{ width: `${Math.min(100, (xp.xp / xpToNext(xp.level)) * 100)}%` }} />
              </div>
            </div>
          )}
        </>
      ) : (
        <p className="mt-0.5 text-right text-xs tabular-nums text-muted">{Math.round(pct)}%</p>
      )}
      {(sts.length > 0 || snap.haste > 0) && (
        <div className="mt-1.5 flex flex-wrap gap-1">
          {sts.map((s) => (
            <span key={s} className="rounded-full px-2 py-0.5 text-[10px] font-bold text-black" style={{ backgroundColor: STATUS_COLOR[s] }}>
              {STATUS_LABEL[s]}
            </span>
          ))}
          {snap.haste > 0 && <span className="rounded-full bg-emerald-300 px-2 py-0.5 text-[10px] font-bold text-black">Veloz</span>}
        </div>
      )}
    </div>
  );
}

function moveHint(m: Move, foe: Combatant): { sym: string; label: string; cls: string } | null {
  if (m.power <= 0 || m.family === "body") return null;
  const mu = matchup(m.family, foe.family);
  if (mu.kind === "super") return { sym: "▲", label: "Eficaz", cls: "text-emerald-300" };
  if (mu.kind === "weak") return { sym: "▼", label: "Débil", cls: "text-rose-300" };
  return null;
}

export function Battle({
  setup,
  onWin,
  onLose,
}: {
  setup: BattleSetup;
  onWin: () => void;
  onLose: (next: "retry" | "map") => void;
}) {
  const [battle, setBattle] = useState<BattleState>(() => {
    const rng = mulberry(setup.seed ^ 0x9e3779b9);
    return startBattle(structuredClone(setup.you), structuredClone(setup.foe), rng);
  });
  const battleRef = useRef(battle);
  const rngRef = useRef(mulberry(setup.seed));
  const [view, setView] = useState(() => snapshot(battle));
  const [phase, setPhase] = useState<"intro" | "choose" | "busy" | "end">("intro");
  const [menu, setMenu] = useState<"main" | "tech">("main");
  const [text, setText] = useState("");
  const [fx, setFx] = useState<ActiveFx | null>(null);
  const [pops, setPops] = useState<{ id: number; side: Side; text: string; tone: string }[]>([]);
  const [hit, setHit] = useState<Side | null>(null);
  const [faint, setFaint] = useState<Side | null>(null);
  const [lunge, setLunge] = useState<{ side: Side; lx: number; ly: number; kind: "lunge" | "cast"; color: string } | null>(null);
  const [shake, setShake] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);
  const [chart, setChart] = useState(false);
  const [fast, setFast] = useState(false);
  const [endResult, setEndResult] = useState<"win" | "lose" | null>(null);

  const stageRef = useRef<HTMLDivElement>(null);
  const youRef = useRef<HTMLDivElement>(null);
  const foeRef = useRef<HTMLDivElement>(null);
  const token = useRef(0);
  const uid = useRef(1);
  const skip = useRef(false);
  const fastRef = useRef(false);
  fastRef.current = fast;

  const centerOf = (side: Side): Pt => {
    const st = stageRef.current?.getBoundingClientRect();
    const el = (side === "you" ? youRef : foeRef).current?.getBoundingClientRect();
    if (!st || !el) return { x: side === "you" ? 90 : 260, y: side === "you" ? 200 : 90 };
    return { x: el.left - st.left + el.width / 2, y: el.top - st.top + el.height / 2 };
  };

  const sleep = (ms: number) =>
    new Promise<void>((res) => {
      const k = skip.current ? 0.18 : fastRef.current ? 0.5 : 1;
      setTimeout(res, Math.max(30, ms * k));
    });

  const typeText = async (t: string, tk: number) => {
    skip.current = false;
    let i = 0;
    while (i < t.length) {
      if (token.current !== tk) return;
      i = skip.current ? t.length : Math.min(t.length, i + 2);
      setText(t.slice(0, i));
      if (i < t.length) await sleep(fastRef.current ? 10 : 22);
    }
    setText(t);
  };

  const addPop = (side: Side, t: string, tone: string) => {
    const id = uid.current++;
    setPops((p) => [...p, { id, side, text: t, tone }]);
    setTimeout(() => setPops((p) => p.filter((x) => x.id !== id)), 1100);
  };

  const playBeats = async (beats: Beat[], tk: number) => {
    for (const beat of beats) {
      if (token.current !== tk) return;
      await typeText(beat.text, tk);
      if (token.current !== tk) return;
      if (beat.fx) {
        setView(beat.snap);
        const a = centerOf(beat.fx.from);
        const b = centerOf(beat.fx.to);
        const id = uid.current++;
        const melee = beat.fx.kind === "punch" || beat.fx.kind === "kick";
        const ox = (b.x - a.x) * 0.55;
        const oy = (b.y - a.y) * 0.55;
        setLunge({ side: beat.fx.from, lx: melee ? ox : ox * 0.06, ly: melee ? oy : oy * 0.06, kind: melee ? "lunge" : "cast", color: beat.fx.color });
        setFx({ ...beat.fx, id, a, b });
        await sleep(FX_MS[beat.fx.kind] ?? 700);
        if (token.current !== tk) return;
        setFx(null);
        setLunge(null);
      } else setView(beat.snap);
      if (beat.hit) {
        setHit(beat.hit);
        setTimeout(() => setHit(null), 520);
        if (beat.sfx === "crit" || beat.sfx === "super") {
          setShake(true);
          setTimeout(() => setShake(false), 420);
          setFlash(beat.pop ? (beat.sfx === "crit" ? "#fde68a" : "#ffffff") : null);
          setTimeout(() => setFlash(null), 360);
        }
      }
      if (beat.faint) setFaint(beat.faint);
      if (beat.pop) addPop(beat.pop.side, beat.pop.text, beat.pop.tone);
      if (beat.sfx) blip(beat.sfx);
      await sleep(beat.faint ? 1100 : beat.hit ? 760 : beat.pop ? 560 : beat.fx ? 260 : 420);
    }
  };

  const prompt = (b: BattleState) =>
    b.readNext ? `Lees su gesto: el rival usará ${describeChoice(b.foe, b.plan)}. ¿Qué hará ${b.you.name}?` : `¿Qué hará ${b.you.name}?`;

  useEffect(() => {
    const tk = ++token.current;
    (async () => {
      for (const line of setup.intro) {
        await typeText(line, tk);
        if (token.current !== tk) return;
        await sleep(Math.min(2600, 750 + line.length * 24));
        if (token.current !== tk) return;
      }
      setText(prompt(battleRef.current));
      setPhase("choose");
    })();
    const tokenRef = token;
    return () => {
      tokenRef.current++;
    };
    // la intro solo corre una vez por duelo
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const choose = async (choice: Choice) => {
    if (phase !== "choose") return;
    unlockAudio();
    setPhase("busy");
    setMenu("main");
    const tk = ++token.current;
    const { battle: next, beats } = playTurn(battleRef.current, choice, rngRef.current);
    await playBeats(beats, tk);
    if (token.current !== tk) return;
    battleRef.current = next;
    setBattle(next);
    setView(snapshot(next));
    if (next.over) {
      setEndResult(next.over);
      setPhase("end");
      setText(next.over === "win" ? "¡Ganaste el duelo!" : "Tu dōjutsu parpadea y se apaga…");
      return;
    }
    setText(prompt(next));
    setPhase("choose");
  };

  const you = battle.you;
  const foe = battle.foe;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === " " || e.key === "Enter") {
        if (phase === "busy" || phase === "intro") {
          e.preventDefault();
          skip.current = true;
        }
        return;
      }
      if (phase !== "choose") return;
      if (menu === "main") {
        if (e.key === "1") void choose({ kind: "strike" });
        else if (e.key === "2") setMenu("tech");
        else if (e.key === "3") void choose({ kind: "guard" });
        else if (e.key === "4" && you.chakra >= 6) void choose({ kind: "read" });
      } else {
        const i = Number(e.key) - 1;
        if (i >= 0 && i < 4) {
          const m = you.moves[i];
          if (m && canUse(you, m)) void choose({ kind: "move", index: i });
        } else if (e.key === "Escape" || e.key === "Backspace") setMenu("main");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const [bgA, bgB] = LAND_BG[setup.landId] ?? ["#2a1a10", "#100a06"];
  const youCls = [
    "bt-bob",
    faint === "you" ? "bt-faint" : "",
    hit === "you" ? "bt-hit" : "",
    lunge?.side === "you" ? (lunge.kind === "lunge" ? "bt-lunge" : "bt-cast") : "",
  ].join(" ");
  const foeCls = [
    "bt-bob-slow",
    faint === "foe" ? "bt-faint" : "",
    hit === "foe" ? "bt-hit" : "",
    lunge?.side === "foe" ? (lunge.kind === "lunge" ? "bt-lunge" : "bt-cast") : "",
  ].join(" ");

  const end = useMemo(() => {
    if (endResult === "win") {
      const r = applyXp(setup.level, setup.xp, setup.xpWin);
      const learned = you.moves.filter((m) => m.unlock > setup.level && m.unlock <= r.level);
      const lm1 = levelMul(setup.level);
      const lm2 = levelMul(r.level);
      const hp = Math.round(5 * (r.level - setup.level) + 0.7 * you.stats.p * (lm2 - lm1));
      return { gain: setup.xpWin, r, learned, hp };
    }
    if (endResult === "lose") return { gain: setup.xpLose, r: applyXp(setup.level, setup.xp, setup.xpLose), learned: [] as Move[], hp: 0 };
    return null;
  }, [endResult, setup, you]);

  useEffect(() => {
    if (end && end.r.ups.length) blip("levelup");
  }, [end]);

  const lungeStyle = (side: Side): CSSProperties | undefined =>
    lunge?.side === side ? cv({ "--lx": `${lunge.lx}px`, "--ly": `${lunge.ly}px`, "--c": lunge.color }) : undefined;

  return (
    <section>
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="min-w-0 truncate text-sm font-semibold text-gold">
          {setup.landName} · duelo {setup.fightIndex + 1} de 3{setup.boss ? " · jefe" : ""}
        </p>
        <div className="flex shrink-0 gap-2">
          <button type="button" className="rounded-lg border border-line bg-raised px-2.5 py-1.5 text-xs font-semibold hover:border-gold" onClick={() => setChart((c) => !c)}>
            Elementos
          </button>
          <button
            type="button"
            aria-pressed={fast}
            className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1.5 text-xs font-semibold ${fast ? "border-gold bg-gold text-on-primary" : "border-line bg-raised hover:border-gold"}`}
            onClick={() => setFast((f) => !f)}
          >
            <FastForward className="size-3.5" aria-hidden />
            Rápido
          </button>
        </div>
      </div>

      {chart && (
        <div className="mb-2 rounded-xl border border-line bg-surface p-3 text-sm">
          <p className="mb-2 font-semibold">Quién vence a quién (×1,6 de daño; al revés, ×0,6)</p>
          <div className="grid gap-1.5 sm:grid-cols-2">
            {CHART_LINES.map((l) => (
              <p key={`${l.a}-${l.b}`} className="flex items-center gap-2">
                <span className="rounded px-1.5 py-0.5 text-xs font-bold text-black" style={{ backgroundColor: familyColor(l.a) }}>
                  {familyLabel(l.a)}
                </span>
                <span aria-hidden>→</span>
                <span className="rounded px-1.5 py-0.5 text-xs font-bold text-black" style={{ backgroundColor: familyColor(l.b) }}>
                  {familyLabel(l.b)}
                </span>
                <span className="truncate text-xs text-muted">{l.note}</span>
              </p>
            ))}
          </div>
        </div>
      )}

      <div
        ref={stageRef}
        className={`relative h-[360px] overflow-hidden rounded-2xl border border-line sm:h-[420px] ${shake ? "bt-stage-shake" : ""}`}
        style={{ background: `radial-gradient(ellipse at 70% 20%, ${bgA}, ${bgB} 70%)` }}
      >
        <div className="absolute right-[4%] top-[34%] h-6 w-[38%] rounded-[50%] bg-black/35 blur-[2px] sm:top-[36%]" />
        <div className="absolute bottom-[12%] left-[2%] h-8 w-[46%] rounded-[50%] bg-black/40 blur-[2px]" />

        <div className="absolute left-2 top-2 w-[56%] max-w-[260px]">
          <Plate c={foe} snap={view.foe} side="foe" />
        </div>
        <div className="absolute bottom-2 right-2 w-[58%] max-w-[280px]">
          <Plate c={you} snap={view.you} side="you" xp={{ level: setup.level, xp: setup.xp }} />
        </div>

        <div ref={foeRef} className="absolute right-[7%] top-[12%] w-24 sm:right-[10%] sm:w-32" style={lungeStyle("foe")}>
          <div className={foeCls}>
            <div className="[&>svg]:h-full [&>svg]:w-full">
              <EyeGlyph eye={foe.eye} size={128} spin />
            </div>
          </div>
        </div>
        <div ref={youRef} className="absolute bottom-[19%] left-[5%] w-28 sm:left-[8%] sm:w-40" style={lungeStyle("you")}>
          <div className={youCls}>
            <div className="[&>svg]:h-full [&>svg]:w-full">
              <EyeGlyph eye={you.eye} size={160} spin />
            </div>
          </div>
        </div>

        {pops.map((p) => {
          const c = centerOf(p.side);
          const tone =
            p.tone === "heal"
              ? "text-emerald-300 text-xl"
              : p.tone === "crit"
                ? "text-yellow-300 text-3xl"
                : p.tone === "super"
                  ? "text-orange-300 text-2xl"
                  : p.tone === "weak"
                    ? "text-slate-300 text-lg"
                    : p.tone === "miss"
                      ? "text-slate-300 text-lg italic"
                      : p.tone === "status"
                        ? "text-violet-300 text-lg"
                        : "text-white text-2xl";
          return (
            <span key={p.id} className={`bt-pop absolute z-20 whitespace-nowrap font-display font-extrabold [text-shadow:0_2px_0_#000,0_0_8px_#000] ${tone}`} style={{ left: c.x, top: c.y - 40 }}>
              {p.text}
            </span>
          );
        })}

        {fx && (
          <div className="pointer-events-none absolute inset-0 z-10" key={fx.id}>
            <FxView fx={fx} />
          </div>
        )}
        {flash && <div className="bt-flash pointer-events-none absolute inset-0 z-30" style={{ backgroundColor: flash }} />}
      </div>

      <div className="mt-3 grid gap-2 md:grid-cols-[1fr_340px]">
        <button
          type="button"
          onClick={() => {
            skip.current = true;
          }}
          className="relative min-h-[104px] rounded-2xl border-2 border-gold/70 bg-surface p-4 text-left text-base leading-relaxed"
          aria-live="polite"
        >
          {text}
          {(phase === "busy" || phase === "intro") && <span className="bt-blink absolute bottom-2 right-3 text-gold">▼</span>}
        </button>

        <div className="min-h-[104px]">
          {phase === "choose" && menu === "main" && (
            <div className="grid grid-cols-2 gap-2">
              <button type="button" className={btnPrimary} onClick={() => void choose({ kind: "strike" })}>
                <Swords className="size-4" aria-hidden />
                Golpear
              </button>
              <button type="button" className={btnGhost} onClick={() => setMenu("tech")}>
                <Sparkles className="size-4" aria-hidden />
                Técnicas
              </button>
              <button type="button" className={btnGhost} onClick={() => void choose({ kind: "guard" })}>
                <Shield className="size-4" aria-hidden />
                Guardia
              </button>
              <button type="button" disabled={you.chakra < 6} className={`${btnGhost} disabled:cursor-not-allowed disabled:opacity-40`} onClick={() => void choose({ kind: "read" })}>
                <EyeIcon className="size-4" aria-hidden />
                Percibir
              </button>
              <p className="col-span-2 text-xs text-muted">Golpear no gasta chakra. Guardia recupera chakra y frena el próximo golpe. Percibir cuesta 6 y revela el siguiente movimiento rival.</p>
            </div>
          )}

          {phase === "choose" && menu === "tech" && (
            <div>
              <div className="grid grid-cols-2 gap-2">
                {you.moves.map((m, i) => {
                  const known = isKnown(you, m);
                  const cd = you.cds[m.id] ?? 0;
                  const cost = costOf(you, m);
                  const ok = canUse(you, m);
                  const h = moveHint(m, foe);
                  const col = familyColor(m.family);
                  return (
                    <button
                      key={m.id}
                      type="button"
                      disabled={!ok}
                      onClick={() => void choose({ kind: "move", index: i })}
                      title={m.blurb}
                      className="flex min-h-16 flex-col items-start justify-between gap-0.5 rounded-xl border bg-raised p-2 text-left transition-colors hover:border-gold disabled:cursor-not-allowed disabled:opacity-45"
                      style={{ borderColor: ok ? col : undefined }}
                    >
                      <span className="line-clamp-2 text-[13px] font-bold leading-tight">
                        {i + 1}. {m.name}
                        {h && (
                          <span className={`ml-1 ${h.cls}`} title={h.label}>
                            {h.sym}
                          </span>
                        )}
                      </span>
                      <span className="flex w-full items-center justify-between gap-1 text-[11px] text-muted">
                        <span className="rounded px-1 font-bold text-black" style={{ backgroundColor: col }}>
                          {familyLabel(m.family)}
                        </span>
                        <span>
                          {!known ? `Nivel ${m.unlock}` : cd > 0 ? `espera ${cd}` : m.power > 0 ? `Pod ${m.power} · ${cost}` : `Cura · ${cost}`}
                        </span>
                      </span>
                      {known && describeEffects(m).length > 0 && <span className="line-clamp-1 text-[10px] text-gold">{describeEffects(m).join(" · ")}</span>}
                    </button>
                  );
                })}
              </div>
              <button type="button" className="mt-2 inline-flex items-center gap-1 text-sm text-muted hover:text-fg" onClick={() => setMenu("main")}>
                <ChevronLeft className="size-4" aria-hidden />
                Volver
              </button>
            </div>
          )}

          {phase !== "choose" && phase !== "end" && <p className="px-1 pt-2 text-xs text-muted">Toca el cuadro de texto (o Espacio) para avanzar más rápido.</p>}
        </div>
      </div>

      {phase === "end" && end && (
        <div className={`mt-3 rounded-2xl border bg-raised p-4 ${endResult === "win" ? "border-gold" : "border-blood"}`}>
          {endResult === "win" ? (
            <>
              <p className="font-display text-xl">¡Victoria!</p>
              <p className="mt-1 text-sm text-muted">{foe.eye.famous}</p>
            </>
          ) : (
            <>
              <p className="font-display text-xl">Tu dōjutsu parpadea.</p>
              <p className="mt-1 text-sm text-muted">El pacto no te ejecuta. Exige que mires otra vez.</p>
            </>
          )}
          <p className="mt-2 text-sm">
            +{end.gain} EXP{endResult === "lose" ? " de consuelo" : ""}
          </p>
          {end.r.ups.length > 0 && (
            <div className="mt-2 rounded-xl border border-gold bg-bg p-3 text-sm">
              <p className="font-semibold text-gold">¡Subes al nivel {end.r.level}!</p>
              {end.hp > 0 && <p className="text-muted">Vida máxima +{end.hp}</p>}
              {end.learned.map((m) => (
                <p key={m.id} className="mt-1">
                  Nueva técnica: <span className="font-semibold">{m.name}</span> <span className="text-muted">({familyLabel(m.family)})</span>
                </p>
              ))}
            </div>
          )}
          {endResult === "win" && setup.fightIndex >= 2 && <p className="mt-2 text-sm leading-relaxed text-muted">{setup.outro}</p>}
          <div className="mt-3 flex flex-col gap-2 sm:flex-row">
            {endResult === "win" ? (
              <button type="button" className={btnPrimary} onClick={onWin}>
                {setup.fightIndex >= 2 ? "Cerrar el país" : "Siguiente duelo"}
              </button>
            ) : (
              <>
                <button type="button" className={btnPrimary} onClick={() => onLose("retry")}>
                  <RotateCcw className="size-4" aria-hidden />
                  Reintentar
                </button>
                <button type="button" className={btnGhost} onClick={() => onLose("map")}>
                  Volver al mapa
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
