import { useId } from "react";
import type { Eye } from "@/game/types";

type Ornament =
  | { kind: "multi"; n: number }
  | { kind: "slit" }
  | { kind: "star"; n: number }
  | { kind: "moon" }
  | { kind: "ring" }
  | { kind: "tomoe"; n: number }
  | { kind: "grid" }
  | { kind: "round" };

function ornament(pupil: string): Ornament {
  const p = pupil.toLowerCase();
  const multi = p.match(/multi_iris_(\d+)/);
  if (multi) return { kind: "multi", n: Math.min(7, Number(multi[1]) || 3) };
  if (/slit|dragon|reptile|viper|feline|serpent|serpent/.test(p)) return { kind: "slit" };
  if (/star|pentagram|hexagram|hepta|octa|agram|trigram/.test(p)) {
    const n = /hexa|6/.test(p) ? 6 : /hepta|7/.test(p) ? 7 : /octa|8/.test(p) ? 8 : /tetra|4/.test(p) ? 4 : 5;
    return { kind: "star", n };
  }
  if (/moon|eclipse|crescent/.test(p)) return { kind: "moon" };
  if (/ring|wheel|chrono/.test(p)) return { kind: "ring" };
  if (/tomoe|drop|blood/.test(p)) {
    const n = /pent|5/.test(p) ? 5 : /hex|6/.test(p) ? 6 : /tri|3/.test(p) ? 3 : /dual|double|2/.test(p) ? 2 : 1;
    return { kind: "tomoe", n };
  }
  if (/grid|insect|compound|spider/.test(p)) return { kind: "grid" };
  return { kind: "round" };
}

function starPoints(cx: number, cy: number, r: number, spikes: number) {
  const pts: string[] = [];
  for (let i = 0; i < spikes * 2; i++) {
    const rad = i % 2 === 0 ? r : r * 0.42;
    const a = -Math.PI / 2 + (i * Math.PI) / spikes;
    pts.push(`${cx + Math.cos(a) * rad},${cy + Math.sin(a) * rad}`);
  }
  return pts.join(" ");
}

export function EyeGlyph({ eye, size = 148, spin = false }: { eye: Eye; size?: number; spin?: boolean }) {
  const uid = useId().replace(/:/g, "");
  const o = ornament(eye.pupil);
  const gIris = `iris-${uid}`;
  const gGlow = `glow-${uid}`;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      role="img"
      aria-label={eye.name}
      className="shrink-0"
      style={{ filter: `drop-shadow(0 0 10px ${eye.glow})` }}
    >
      <defs>
        <radialGradient id={gIris} cx="50%" cy="42%" r="60%">
          <stop offset="0%" stopColor={eye.iris} />
          <stop offset="70%" stopColor={eye.iris2} />
          <stop offset="100%" stopColor="#0a0908" />
        </radialGradient>
        <radialGradient id={gGlow} cx="50%" cy="50%" r="50%">
          <stop offset="60%" stopColor={eye.glow} stopOpacity="0" />
          <stop offset="100%" stopColor={eye.glow} stopOpacity="0.55" />
        </radialGradient>
      </defs>
      <ellipse cx="50" cy="50" rx="47" ry="32" fill={eye.sclera} />
      <ellipse cx="50" cy="50" rx="47" ry="32" fill="none" stroke="#1a120c" strokeWidth="1.4" />
      <path d="M6 50 Q50 18 94 50" fill="none" stroke="#1a120c" strokeWidth="3.2" opacity="0.35" />
      <g className={spin ? "iris-spin" : undefined}>
        <circle cx="50" cy="50" r="23" fill={`url(#${gIris})`} />
        <circle cx="50" cy="50" r="23" fill={`url(#${gGlow})`} />
        {o.kind === "multi" &&
          Array.from({ length: o.n }, (_, i) => {
            const a = (i / o.n) * Math.PI * 2 - Math.PI / 2;
            const cx = 50 + Math.cos(a) * 11;
            const cy = 50 + Math.sin(a) * 11;
            return (
              <g key={i}>
                <circle cx={cx} cy={cy} r="6.2" fill={eye.iris} stroke={eye.iris2} strokeWidth="0.6" />
                <circle cx={cx} cy={cy} r="2.2" fill="#0b0a09" />
              </g>
            );
          })}
        {o.kind === "tomoe" &&
          Array.from({ length: o.n }, (_, i) => {
            const a = (i / Math.max(1, o.n)) * Math.PI * 2 - Math.PI / 2;
            const cx = 50 + Math.cos(a) * 12;
            const cy = 50 + Math.sin(a) * 12;
            return <ellipse key={i} cx={cx} cy={cy} rx="3.3" ry="5" fill="#140c0c" transform={`rotate(${(a * 180) / Math.PI + 90} ${cx} ${cy})`} />;
          })}
        {o.kind === "star" && <polygon points={starPoints(50, 50, 12, o.n)} fill="#100c0a" />}
        {o.kind === "slit" && <ellipse cx="50" cy="50" rx="3.2" ry="14" fill="#100c0a" />}
        {o.kind === "moon" && (
          <g>
            <circle cx="50" cy="50" r="11" fill="#100c0a" />
            <circle cx="55" cy="47" r="9" fill={eye.iris} />
          </g>
        )}
        {o.kind === "ring" && (
          <g fill="none" stroke="#100c0a" strokeWidth="1.6">
            <circle cx="50" cy="50" r="11" />
            <circle cx="50" cy="50" r="6" />
          </g>
        )}
        {o.kind === "grid" && (
          <g stroke="#100c0a" strokeWidth="0.7" opacity="0.85">
            <path d="M40 50 H60 M50 40 V60 M42 43 L58 57 M58 43 L42 57" />
          </g>
        )}
        {(o.kind === "round" || o.kind === "grid" || o.kind === "tomoe" || o.kind === "ring") && (
          <circle cx="50" cy="50" r={o.kind === "tomoe" ? 5 : 6.5} fill="#0c0b0a" />
        )}
        <circle cx="44" cy="44" r="4" fill="#fff" opacity="0.28" />
      </g>
    </svg>
  );
}
