export type Stats = { g: number; p: number; n: number; d: number; r: number };

export type Eye = {
  id: string;
  name: string;
  jp: string;
  kanji: string;
  classification: string;
  clan: string;
  rank: string;
  tier: number;
  element: string;
  family: string;
  look: string;
  iris: string;
  iris2: string;
  pupil: string;
  sclera: string;
  glow: string;
  stats: Stats;
  origin: string;
  awakening: string;
  ability: string;
  apex: string;
  costNote: string;
  famous: string;
};

export type Modifier = {
  id: string;
  name: string;
  kanji: string;
  category: "rune" | "mark" | "scar" | "tattoo";
  origin: string;
  explanation: string;
  extra: string;
  symbolism: string;
  color: string;
};

export type Race = {
  id: string;
  name: string;
  jp: string;
  kanji: string;
  title: string;
  symbolName: string;
  philosophy: string;
  culture: string;
  chakraType: string;
  elements: string[];
  resistance: string;
  theme: string;
  accent: string;
  mods: { runeId?: string; markId?: string; scarId?: string; tattooId?: string };
};

export type Clan = {
  id: string;
  name: string;
  kanji: string;
  settlement: string;
  status: string;
  relation: string;
  lore: string;
  eyeIds: string[];
};

export type Land = {
  id: string;
  name: string;
  sub: string;
  element: string;
  description: string;
  treaty: string;
  clans: Clan[];
};

export type Loadout = {
  rune: string | null;
  mark: string | null;
  scar: string | null;
  tattoo: string | null;
};

export type Fx =
  | "orb"
  | "whirl"
  | "beam"
  | "slash"
  | "claw"
  | "bolt"
  | "wave"
  | "burst"
  | "rain"
  | "pillar"
  | "pulse"
  | "heal"
  | "guard"
  | "punch"
  | "kick";

export type Status = "burn" | "bleed" | "poison" | "stun" | "slow" | "blind";
export type School = "nin" | "gen" | "body";

export type MoveEffect =
  | { kind: "status"; status: Status; chance: number }
  | { kind: "heal"; pct: number }
  | { kind: "drain"; pct: number }
  | { kind: "guard"; pct: number }
  | { kind: "haste" };

export type Move = {
  id: string;
  slot: "common-a" | "unique" | "common-b" | "apex" | "body";
  name: string;
  family: string;
  school: School;
  power: number;
  cost: number;
  acc: number;
  fx: Fx;
  effects: MoveEffect[];
  cd: number;
  unlock: number;
  unique: boolean;
  blurb: string;
};

export type Side = "you" | "foe";

export type Snap = {
  hp: number;
  chakra: number;
  status: Partial<Record<Status, number>>;
  guard: number;
  haste: number;
};

export type Beat = {
  text: string;
  fx?: { kind: Fx; color: string; from: Side; to: Side; family: string };
  pop?: { side: Side; text: string; tone: "dmg" | "crit" | "heal" | "miss" | "status" | "super" | "weak" };
  hit?: Side;
  faint?: Side;
  sfx?: "hit" | "crit" | "heal" | "miss" | "status" | "super" | "weak" | "win" | "lose" | "ui";
  snap: { you: Snap; foe: Snap };
};

export type Combatant = {
  name: string;
  eye: Eye;
  family: string;
  level: number;
  stats: Stats;
  hp: number;
  hpMax: number;
  chakra: number;
  chakraMax: number;
  moves: Move[];
  unlockBoost: number;
  cds: Record<string, number>;
  status: Partial<Record<Status, number>>;
  guard: number;
  haste: number;
  evade: boolean;
  wild: boolean;
  outMul: number;
  inGen: number;
  outGen: number;
  outNin: number;
  elemBias: string | null;
  channelPlus: number;
  guardHeal: number;
  apexOff: number;
  lowHpN: number;
  apexCdCut: number;
};

export type Choice = { kind: "strike" } | { kind: "move"; index: number } | { kind: "guard" } | { kind: "read" };

export type Phase =
  | "title"
  | "lineage"
  | "oath"
  | "map"
  | "armory"
  | "duel"
  | "awaken"
  | "ending"
  | "codex";
