import { familyColor } from "./elements";
import { fold, moveBlurb, shortMove } from "./text";
import type { Eye, Fx, Move, MoveEffect, School, Status } from "./types";

type Tpl = {
  name: string;
  school: School;
  power: number;
  cost: number;
  acc: number;
  fx: Fx;
  effects: MoveEffect[];
  blurb: string;
};

/**
 * Técnicas comunes: las comparten todos los ojos de la misma familia.
 * Cada ojo suma además una habilidad única y un jutsu prohibido sacados de su ficha en el archivo.
 */
const COMMON: Record<string, [Tpl, Tpl]> = {
  fire: [
    { name: "Bola de fuego", school: "nin", power: 42, cost: 8, acc: 100, fx: "orb", effects: [{ kind: "status", status: "burn", chance: 20 }], blurb: "Una esfera de llamas. Puede dejar al rival ardiendo." },
    { name: "Oleada ígnea", school: "nin", power: 62, cost: 14, acc: 95, fx: "wave", effects: [{ kind: "status", status: "burn", chance: 30 }], blurb: "Una ola de fuego que barre el campo." },
  ],
  wind: [
    { name: "Bola de aire", school: "nin", power: 40, cost: 8, acc: 100, fx: "orb", effects: [], blurb: "Aire comprimido lanzado como un cañonazo." },
    { name: "Remolino", school: "nin", power: 58, cost: 13, acc: 95, fx: "whirl", effects: [{ kind: "status", status: "slow", chance: 35 }], blurb: "Un torbellino que arrastra al rival y lo frena." },
  ],
  lightning: [
    { name: "Chispazo", school: "nin", power: 44, cost: 9, acc: 100, fx: "bolt", effects: [{ kind: "status", status: "stun", chance: 12 }], blurb: "Una descarga rápida. A veces deja aturdido." },
    { name: "Cadena de rayos", school: "nin", power: 64, cost: 15, acc: 92, fx: "bolt", effects: [{ kind: "status", status: "stun", chance: 25 }], blurb: "Rayos encadenados que saltan de nervio a nervio." },
  ],
  earth: [
    { name: "Lanzarrocas", school: "nin", power: 46, cost: 9, acc: 100, fx: "orb", effects: [], blurb: "Un bloque de roca disparado a toda velocidad." },
    { name: "Temblor", school: "nin", power: 64, cost: 15, acc: 95, fx: "pillar", effects: [{ kind: "status", status: "stun", chance: 20 }], blurb: "El suelo se quiebra bajo el rival." },
  ],
  water: [
    { name: "Chorro de agua", school: "nin", power: 42, cost: 8, acc: 100, fx: "beam", effects: [], blurb: "Un chorro a presión que corta como un látigo." },
    { name: "Marea alta", school: "nin", power: 60, cost: 14, acc: 95, fx: "wave", effects: [{ kind: "status", status: "slow", chance: 30 }], blurb: "Una marea que empapa y entorpece." },
  ],
  yin: [
    { name: "Niebla umbría", school: "gen", power: 40, cost: 8, acc: 100, fx: "pulse", effects: [{ kind: "status", status: "blind", chance: 35 }], blurb: "Bruma negra que nubla la vista del rival." },
    { name: "Pesadilla", school: "gen", power: 60, cost: 14, acc: 95, fx: "whirl", effects: [{ kind: "status", status: "stun", chance: 25 }], blurb: "Una ilusión que paraliza la mente un instante." },
  ],
  yang: [
    { name: "Destello solar", school: "nin", power: 44, cost: 9, acc: 100, fx: "beam", effects: [{ kind: "status", status: "blind", chance: 20 }], blurb: "Un haz de luz que quema y deslumbra." },
    { name: "Luz sanadora", school: "nin", power: 0, cost: 14, acc: 100, fx: "heal", effects: [{ kind: "heal", pct: 32 }], blurb: "Recupera un tercio de tu vida." },
  ],
  void: [
    { name: "Esfera del vacío", school: "gen", power: 46, cost: 10, acc: 100, fx: "orb", effects: [], blurb: "Una esfera que se come la luz a su paso." },
    { name: "Pliegue gravitatorio", school: "gen", power: 62, cost: 15, acc: 95, fx: "pulse", effects: [{ kind: "status", status: "slow", chance: 40 }], blurb: "Dobla el espacio y aplasta los movimientos del rival." },
  ],
  blood: [
    { name: "Aguja de sangre", school: "nin", power: 44, cost: 8, acc: 100, fx: "claw", effects: [{ kind: "status", status: "bleed", chance: 30 }], blurb: "Una aguja carmesí que abre heridas." },
    { name: "Hervor carmesí", school: "nin", power: 62, cost: 14, acc: 95, fx: "burst", effects: [{ kind: "status", status: "bleed", chance: 45 }], blurb: "La sangre del rival hierve y se desborda." },
  ],
};

export const STRIKE: Move = {
  id: "strike",
  slot: "body",
  name: "Golpear",
  family: "body",
  school: "body",
  power: 32,
  cost: 0,
  acc: 100,
  fx: "punch",
  effects: [],
  cd: 0,
  unlock: 1,
  unique: false,
  blurb: "Puñetazo o patada. No gasta chakra y devuelve un poco.",
};

export const STRIKE_FORMS: { verb: string; fx: Fx }[] = [
  { verb: "lanza un puñetazo", fx: "punch" },
  { verb: "mete una patada", fx: "kick" },
  { verb: "encadena puño y rodilla", fx: "punch" },
  { verb: "gira y patea", fx: "kick" },
  { verb: "carga con el hombro", fx: "punch" },
];

export const UNLOCK = { a: 1, unique: 1, b: 6, apex: 12 } as const;

const R = {
  blind: /ciega|ceguera|oscuridad|cegador|deslumbr|niebla|bruma|invisib|humo|hollin|polvo|eclipse|camufl|vendaval/,
  stun: /paraliza|paralisis|inmoviliza|petrific|congela|sella|bloquea|atrapa|aprision|encierra|momific|capullo|prision|cadenas|hilos|sarcofag|ataud|veda|aturde|noquea|hipnot|enjaula|clausura|cierra sus/,
  slow: /ralentiza|aplasta|gravedad|peso|dilata|lento|lentitud|atrae|presion|pesad|fatiga|entumece|frena/,
  poison: /veneno|toxi|acido|corros|miasma|asfixia|polen|neuro|ponzona/,
  bleed: /sangr|hemorrag|hierve|hervir|ebullicion|desangr|arteri|hemat|empal|estaca|mordedura|colmillo|desgarr/,
  burn: /fuego|llama|incinera|calcina|lava|magma|ignea|solar|quema|plasma|combusti|funde|fundir|derrite|candente|ascua|brasa|calor|ardi/,
  elec: /rayo|relampago|trueno|voltaic|electr|descarga|centella|sinaps/,
  heal: /regenera|repara|cura |curar|sana|cierra heridas|reconstituye|restablece|coagula|renace|renacimiento|resurreccion|sutura|purifica|preserva|devuelve la actividad|alivia/,
  haste: /velocidad|reflejos|acelera|zig-zag|esquiva|evasi|salto|teletransport|hipersonic|supersonic|rapid|ritmo/,
  guard: /escudo|defensa|desvia|refleja|inmunidad|inmune|neutraliza|barrera|armadura|protege|resiste|cupula|muralla|deflecta|absorbe|devuelve/,
  gen: /ilusi|genjutsu|mente|mental|hipnot|espectral|alma|sentidos|psiqu|pesadilla|sueno|vision|mirada|percib|detecta|revela|visualiza|memoria/,
};

const FX_BY_FAMILY: Record<string, Fx> = {
  fire: "wave",
  wind: "whirl",
  lightning: "bolt",
  earth: "pillar",
  water: "wave",
  yin: "pulse",
  yang: "beam",
  void: "pulse",
  blood: "claw",
};

function pickFx(t: string, family: string, apex: boolean): Fx {
  if (/torbellino|vortice|remolino|espiral|tifon|huracan|ciclon|giro/.test(t)) return "whirl";
  if (/rayo|relampago|trueno|voltaic|descarga|centella|plasma|arco voltaico/.test(t) && family !== "yang") return "bolt";
  if (/garra|colmillo|mordedura|zarpa|mandibula|fauces/.test(t)) return "claw";
  if (/cuchilla|corte|filo|tajo|lanza|aguja|senbon|espada|guadana|latigazo|cuchillas|hoja/.test(t)) return "slash";
  if (/lluvia|rocio|gotas|tinta|polen|espor|diluvio|marea/.test(t)) return family === "water" ? "wave" : "rain";
  if (/pilar|monolit|raices|estalagmit|montan|megalit|brota|emerge|bosque|estaca|fosa|abismos/.test(t)) return "pillar";
  if (/onda|rugido|grito|campana|sonic|ultras|resonan|alarido|frecuencia|zumbido/.test(t)) return "pulse";
  if (/explosi|estall|detona|singularidad|supernova|colapso|cataclism|erupcion|aniquil|apocalipsis|bomba|geiser/.test(t)) return "burst";
  if (/haz|laser|rayo de|proyecta un|dispara|aliento|mirada/.test(t)) return "beam";
  if (/ola|oleada|llamarada|inunda|dragon|serpiente|fauces astrales/.test(t)) return "wave";
  const base = FX_BY_FAMILY[family] ?? "orb";
  return apex && (base === "pulse" || base === "claw") ? "burst" : base;
}

function classify(raw: string, family: string, apex: boolean, tier: number) {
  const t = fold(raw);
  let status: Status | null = null;
  let chance = apex ? 55 : 35;
  if (R.blind.test(t)) status = "blind";
  else if (R.stun.test(t)) status = "stun";
  else if (R.slow.test(t)) status = "slow";
  else if (R.poison.test(t)) status = "poison";
  else if (R.bleed.test(t)) status = "bleed";
  else if (R.burn.test(t)) status = "burn";
  else if (R.elec.test(t)) {
    status = "stun";
    chance = apex ? 40 : 18;
  } else {
    const fall: Record<string, Status> = { fire: "burn", lightning: "stun", water: "slow", blood: "bleed", yin: "blind", earth: "slow", void: "slow" };
    status = fall[family] ?? null;
    chance = 20;
  }
  if (status === "stun" && !apex) chance = Math.min(chance, 25);
  if (status === "stun" && apex) chance = Math.min(chance, 45);
  if (tier === 0) chance = Math.min(chance, 20);

  const effects: MoveEffect[] = [];
  if (status) effects.push({ kind: "status", status, chance });
  if (R.heal.test(t)) effects.push({ kind: "drain", pct: apex ? 50 : 35 });
  else if (R.haste.test(t)) effects.push({ kind: "haste" });
  else if (R.guard.test(t)) effects.push({ kind: "guard", pct: apex ? 35 : 40 });

  const school: School = R.gen.test(t) || family === "yin" ? "gen" : "nin";
  return { effects, fx: pickFx(t, family, apex), school };
}

function fromTpl(eye: Eye, slot: Move["slot"], t: Tpl, unlock: number): Move {
  return { id: `${eye.id}:${slot}`, slot, name: t.name, family: eye.family, school: t.school, power: t.power, cost: t.cost, acc: t.acc, fx: t.fx, effects: t.effects, cd: 0, unlock, unique: false, blurb: t.blurb };
}

function buildMoveset(eye: Eye): Move[] {
  const tier = eye.tier;
  const common = COMMON[eye.family] ?? COMMON.yin!;

  const abilityC = classify(eye.ability, eye.family, false, tier);
  const unique: Move = {
    id: `${eye.id}:unique`,
    slot: "unique",
    name: shortMove(eye.ability),
    family: eye.family,
    school: abilityC.school,
    power: tier === 0 ? 26 : 34 + tier * 4,
    cost: tier === 0 ? 6 : 11 + tier,
    acc: tier === 0 ? 95 : 100,
    fx: abilityC.fx,
    effects: abilityC.effects,
    cd: 0,
    unlock: UNLOCK.unique,
    unique: true,
    blurb: moveBlurb(eye.ability),
  };

  const noApex = /^\s*ninguno/i.test(eye.apex);
  let apex: Move;
  if (noApex) {
    apex = {
      id: `${eye.id}:apex`,
      slot: "apex",
      name: "Esfuerzo del oficio",
      family: eye.family,
      school: "nin",
      power: 64,
      cost: 18,
      acc: 92,
      fx: "burst",
      effects: [],
      cd: 3,
      unlock: UNLOCK.apex,
      unique: false,
      blurb: "Un ojo de oficio no tiene jutsu prohibido, pero sabe darlo todo una vez.",
    };
  } else {
    const c = classify(eye.apex, eye.family, true, tier);
    apex = {
      id: `${eye.id}:apex`,
      slot: "apex",
      name: shortMove(eye.apex),
      family: eye.family,
      school: c.school,
      power: tier === 0 ? 40 : 62 + tier * 5,
      cost: tier === 0 ? 12 : 22 + tier * 2,
      acc: tier === 0 ? 90 : 92,
      fx: c.fx === "pulse" || c.fx === "orb" ? "burst" : c.fx,
      effects: c.effects,
      cd: tier === 0 ? 2 : 3,
      unlock: UNLOCK.apex,
      unique: true,
      blurb: moveBlurb(eye.apex),
    };
  }

  return [fromTpl(eye, "common-a", common[0], UNLOCK.a), unique, fromTpl(eye, "common-b", common[1], UNLOCK.b), apex];
}

const cache = new Map<string, Move[]>();

export function movesetFor(eye: Eye): Move[] {
  const hit = cache.get(eye.id);
  if (hit) return hit;
  const set = buildMoveset(eye);
  cache.set(eye.id, set);
  return set;
}

export function moveColor(m: Move): string {
  return familyColor(m.family);
}

export function describeEffects(m: Move): string[] {
  const out: string[] = [];
  const names: Record<Status, string> = { burn: "quemar", bleed: "sangrado", poison: "veneno", stun: "aturdir", slow: "ralentizar", blind: "cegar" };
  for (const e of m.effects) {
    if (e.kind === "status") out.push(`${names[e.status]} ${e.chance}%`);
    else if (e.kind === "heal") out.push(`cura ${e.pct}%`);
    else if (e.kind === "drain") out.push(`absorbe ${e.pct}%`);
    else if (e.kind === "guard") out.push(`guardia ${e.pct}%`);
    else out.push("más velocidad");
  }
  return out;
}
