import { lore } from "./lore";
import { familyLabel } from "./elements";
import { fold, shortMove } from "./text";
import type { Eye, Race, Stats } from "./types";

export { familyLabel, fold, shortMove };

export const eyes = lore.eyes as Eye[];
export const races = lore.races as Race[];
export const lands = lore.lands;
export const mods = lore.mods;

const eyeMap = new Map(eyes.map((e) => [e.id, e]));
export function eyeById(id: string): Eye | undefined {
  return eyeMap.get(id);
}

type Bonus = Partial<Stats> & {
  hp?: number;
  chakra?: number;
  apexOff?: number;
  lowHpN?: number;
};

export const BONUS: Record<string, { blurb: string; bonus: Bonus }> = {
  "rune-karma-celestial": { blurb: "+8 percepción, −6 drenaje", bonus: { p: 8, d: -6 } },
  "rune-bagua-trigrams": { blurb: "+7 ninjutsu, +4 genjutsu", bonus: { n: 7, g: 4 } },
  "rune-monolith-titan": { blurb: "+10 alcance, +14 vitalidad", bonus: { r: 10, hp: 14 } },
  "rune-primordial-dragon": { blurb: "+10 ninjutsu, +4 drenaje", bonus: { n: 10, d: 4 } },
  "rune-abyssal-kraken": { blurb: "+8 genjutsu, +4 percepción", bonus: { g: 8, p: 4 } },
  "rune-uzumaki-spiral": { blurb: "−10 drenaje, +16 chakra", bonus: { d: -10, chakra: 16 } },
  "mark-curse-heaven": { blurb: "+12 genjutsu, −10 vitalidad", bonus: { g: 12, hp: -10 } },
  "mark-sage-toad": { blurb: "+6 percepción, +6 ninjutsu", bonus: { p: 6, n: 6 } },
  "mark-dragon-scales": { blurb: "+18 vitalidad, +3 drenaje", bonus: { hp: 18, d: 3 } },
  "mark-byakugan-veins": { blurb: "+14 percepción", bonus: { p: 14 } },
  "mark-hive-chitin": { blurb: "−8 drenaje, +4 alcance", bonus: { d: -8, r: 4 } },
  "scar-katana-slash": { blurb: "+6 percepción", bonus: { p: 6 } },
  "scar-bijuu-claw": { blurb: "+8 ninjutsu", bonus: { n: 8 } },
  "scar-suture-transplant": { blurb: "+6 genjutsu, −6 vitalidad", bonus: { g: 6, hp: -6 } },
  "scar-black-lightning-burn": { blurb: "+8 alcance", bonus: { r: 8 } },
  "tattoo-anbu-flame": { blurb: "+5 ninjutsu", bonus: { n: 5 } },
  "tattoo-sealing-kanjis": { blurb: "El jutsu prohibido cuesta −8 chakra", bonus: { apexOff: 8 } },
  "tattoo-blood-tears": { blurb: "+7 genjutsu", bonus: { g: 7 } },
  "tattoo-inuzuka-fangs": { blurb: "+10 ninjutsu bajo el 40% de vida", bonus: { lowHpN: 10 } },
};

export const RACE_DON: Record<string, { label: string; hp?: number; drain?: number; outGen?: number; outNin?: number; inGen?: number; elem?: string; channel?: number; heal?: number; apexCd?: number }> = {
  "race-otsutsuki-celestial": { label: "Los genjutsu ordinarios te rozan menos.", inGen: 0.9 },
  "race-ryujin-dragonkin": { label: "El aliento ígneo carga tu ninjutsu de fuego.", outNin: 1.06, elem: "fire" },
  "race-chigan-bloodspecters": { label: "La ilusión carmesí corta más hondo.", outGen: 1.1 },
  "race-senjutsu-sages": { label: "El senjutsu devuelve más chakra al canalizar.", channel: 8 },
  "race-abyssal-yokai": { label: "La marea negra empuja tu ninjutsu de agua.", outNin: 1.06, elem: "water" },
  "race-cyclopean-titans": { label: "El cuerpo de roca aguanta más.", hp: 14 },
  "race-hive-insectoids": { label: "La colmena reparte el drenaje.", drain: -8 },
  "race-raijin-stormwalkers": { label: "El trueno negro afila tu rayo.", outNin: 1.08, elem: "lightning" },
  "race-sixpaths-monks": { label: "Percibir también cierra heridas leves.", heal: 7 },
  "race-chimera-outcasts": { label: "El sello hereje acorta la espera del jutsu prohibido.", apexCd: -1 },
};

const RACE_WORDS: Record<string, string> = {
  "race-otsutsuki-celestial": "otsutsuki celestial kagetsu rinne byakugan estrella vacio divino lunar cosmos yang luz seis",
  "race-ryujin-dragonkin": "dragon ryu magma fuego lava volcan senjutsu esmeralda tierra dracon",
  "race-chigan-bloodspecters": "chigan sangre chinoike cuervo genjutsu lunar carmesi higan ketsu",
  "race-senjutsu-sages": "senjutsu sabio sapo natural madera mokuton ermita viento tierra",
  "race-abyssal-yokai": "abisal agua tinta kraken marea hielo niebla ilusion oceano",
  "race-cyclopean-titans": "titan ciclope tierra gravedad roca basalto monolito mineral doton",
  "race-hive-insectoids": "insecto aburame colmena polilla kikaichu veneno enjambre arana",
  "race-raijin-stormwalkers": "rayo raiton plasma trueno raijin tormenta relampago metal sonido",
  "race-sixpaths-monks": "monje seis camino iryo sagrado sello yang luz medicinal dharma loto",
  "race-chimera-outcasts": "maldito quimera hibrido sello pentagrama curse chafa aberra fusion",
};

const LAND_WORDS: Record<string, string> = {
  fuego: "fuego sangre madera yin katon llama",
  viento: "viento arena magnet veneno futon",
  agua: "agua hielo ilusion niebla suiton",
  rayo: "rayo plasma sonido metal raiton trueno",
  tierra: "tierra magma bestia mineral doton lava roca",
  "abismo-celestial": "vacio gravedad tiempo yang celestial cosmo lunar",
  "fronteras-libres": "chafa comun neutro oficio practico",
  "hibridaciones-prohibidas": "maldic fusion hibrid pentagram sello quimer hereje",
};

function scoreBlob(eye: Eye, words: string[]): number {
  const blob = fold(`${eye.id} ${eye.name} ${eye.clan} ${eye.classification} ${eye.element} ${eye.rank} ${eye.origin}`);
  let sc = 0;
  for (const w of words) if (w && blob.includes(w)) sc += 1;
  return sc;
}

const poolCache = new Map<string, Eye[]>();

export function poolFor(raceId: string): Eye[] {
  const hit = poolCache.get(raceId);
  if (hit) return hit;
  const words = (RACE_WORDS[raceId] ?? "").split(" ");
  const ranked: { eye: Eye; sc: number }[] = [];
  for (const eye of eyes) {
    const sc = scoreBlob(eye, words);
    if (sc > 0) ranked.push({ eye, sc });
  }
  const pool: Eye[] = [];
  for (let tier = 0; tier <= 6; tier++) {
    const row = ranked.filter((x) => x.eye.tier === tier && !pool.includes(x.eye));
    row.sort((a, b) => b.sc - a.sc || b.eye.stats.g + b.eye.stats.n - (a.eye.stats.g + a.eye.stats.n));
    if (row[0]) pool.push(row[0].eye);
  }
  if (pool.length === 0) pool.push(eyes[0]!);
  poolCache.set(raceId, pool);
  return pool;
}

export function startingEye(raceId: string): Eye {
  const pool = poolFor(raceId);
  return pool.find((e) => e.tier >= 1) ?? pool[0]!;
}

export function nextEye(raceId: string, currentId: string): Eye | null {
  const pool = poolFor(raceId);
  const i = pool.findIndex((e) => e.id === currentId);
  if (i >= 0) return pool[i + 1] ?? null;
  const cur = eyeById(currentId);
  if (!cur) return null;
  return pool.find((e) => e.tier > cur.tier) ?? null;
}

const LAND_FAM: Record<string, string[]> = {
  fuego: ["fire", "blood", "yin"],
  viento: ["wind", "earth"],
  agua: ["water", "yin", "blood"],
  rayo: ["lightning", "void"],
  tierra: ["earth", "fire"],
  "abismo-celestial": ["void", "yang", "yin"],
  "fronteras-libres": ["yin", "wind", "earth", "water", "fire"],
  "hibridaciones-prohibidas": ["blood", "void", "yin", "fire"],
};

export function rivalFor(opts: { landId: string; fightIndex: number; playerTier: number; exclude: string[]; salt: number }): Eye {
  const words = (LAND_WORDS[opts.landId] ?? "").split(" ");
  const families = LAND_FAM[opts.landId] ?? [];
  const fronteras = opts.landId === "fronteras-libres";
  const want = fronteras ? (opts.fightIndex === 2 ? 1 : 0) : opts.fightIndex === 2 ? Math.min(6, opts.playerTier + 1) : opts.playerTier;
  const ranked = eyes
    .filter((eye) => !opts.exclude.includes(eye.id))
    .map((eye) => {
      let sc = scoreBlob(eye, words);
      if (families.includes(eye.family)) sc += 5;
      if (fronteras && eye.tier <= 1) sc += 7;
      if (fronteras && /chafa/i.test(eye.rank)) sc += 4;
      sc -= Math.abs(eye.tier - want) * 2;
      return { eye, sc };
    })
    .filter((x) => x.sc > 0)
    .sort((a, b) => b.sc - a.sc || a.eye.id.localeCompare(b.eye.id));
  const top = ranked.slice(0, 5);
  if (top.length === 0) return eyes.find((e) => !opts.exclude.includes(e.id)) ?? eyes[0]!;
  const idx = Math.abs(opts.salt + opts.fightIndex * 2 + opts.landId.length) % top.length;
  return top[idx]!.eye;
}

export function tierName(tier: number): string {
  return ["Chafa", "Iniciado", "Avanzado", "Élite", "Maestro", "Legendario", "Divino"][tier] ?? "—";
}
