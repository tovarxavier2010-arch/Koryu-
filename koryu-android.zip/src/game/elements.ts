export const NATURES = ["fire", "wind", "lightning", "earth", "water"] as const;

const LABEL: Record<string, string> = {
  fire: "Fuego",
  wind: "Viento",
  lightning: "Rayo",
  earth: "Tierra",
  water: "Agua",
  yin: "Yin",
  yang: "Yang",
  void: "Vacío",
  blood: "Sangre",
  body: "Cuerpo",
};

const COLOR: Record<string, string> = {
  fire: "#f97316",
  wind: "#86efac",
  lightning: "#fde047",
  earth: "#c08a4a",
  water: "#38bdf8",
  yin: "#a855f7",
  yang: "#fde68a",
  void: "#818cf8",
  blood: "#ef4444",
  body: "#e5e7eb",
};

export function familyLabel(id: string): string {
  return LABEL[id] ?? id;
}

export function familyColor(id: string): string {
  return COLOR[id] ?? "#e5e7eb";
}

/** Cada par [A, B] significa: A vence a B. El ciclo clásico es fuego > viento > rayo > tierra > agua > fuego. */
export const BEATS: [string, string][] = [
  ["fire", "wind"],
  ["wind", "lightning"],
  ["lightning", "earth"],
  ["earth", "water"],
  ["water", "fire"],
  ["yin", "yang"],
  ["yang", "yin"],
  ["yang", "void"],
  ["blood", "water"],
  ["blood", "yin"],
  ["yin", "fire"],
  ["void", "earth"],
];

const BEAT_SET = new Set(BEATS.map(([a, b]) => `${a}>${b}`));

export type Matchup = { mult: number; kind: "super" | "weak" | "even" };

export function matchup(atk: string, def: string): Matchup {
  if (BEAT_SET.has(`${atk}>${def}`)) return { mult: 1.6, kind: "super" };
  if (BEAT_SET.has(`${def}>${atk}`)) return { mult: 0.6, kind: "weak" };
  return { mult: 1, kind: "even" };
}

/** Lo que enseña la tabla de elementos en pantalla. */
export const CHART_LINES: { a: string; b: string; note: string }[] = [
  { a: "water", b: "fire", note: "El agua apaga el fuego" },
  { a: "fire", b: "wind", note: "El fuego se alimenta del viento" },
  { a: "wind", b: "lightning", note: "El viento dispersa el rayo" },
  { a: "lightning", b: "earth", note: "El rayo parte la tierra" },
  { a: "earth", b: "water", note: "La tierra embalsa el agua" },
  { a: "yin", b: "yang", note: "La sombra apaga la luz" },
  { a: "yang", b: "yin", note: "La luz rompe la sombra" },
  { a: "yang", b: "void", note: "La luz ilumina el vacío" },
  { a: "blood", b: "water", note: "La sangre tiñe el caudal" },
  { a: "blood", b: "yin", note: "La sangre ancla la sombra" },
  { a: "yin", b: "fire", note: "La sombra ahoga la llama" },
  { a: "void", b: "earth", note: "El vacío traga la roca" },
];
