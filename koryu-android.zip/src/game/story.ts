export type Chapter = {
  title: string;
  intro: string;
  /** Lo que dice el rival al empezar cada uno de los tres duelos (el tercero es el jefe del país). */
  duels: [string, string, string];
  outro: string;
};

export const CHAPTERS: Record<string, Chapter> = {
  fuego: {
    title: "Capítulo I · Ceniza en la Hoja",
    intro: "Tu ojo acaba de despertar y el País del Fuego lo siente. En las fronteras del Valle del Infierno ya se habla de ti. Cruza los tres duelos y los ancianos de la Hoja te dejarán seguir.",
    duels: [
      "Un guardián de patrulla te corta el paso: «Los ojos nuevos se prueban aquí, entre las brasas.»",
      "Desde las aguas termales sube un rival que huele a azufre: «Nadie cruza el valle sin dejar algo de sangre.»",
      "El jefe de la frontera baja del puente. Es el guardián de la Hoja: «Muéstrame qué mira tu ojo de verdad.»",
    ],
    outro: "La Hoja te reconoce. Tu ojo late distinto, como si ya supiera lo que viene.",
  },
  viento: {
    title: "Capítulo II · Tormenta de Arena",
    intro: "El desierto borra los caminos en minutos. En Suna los clanes comercian hilos, sal y venenos, y desconfían de todo ojo que no conocen. Aquí no gana el más fuerte: gana el que sabe leer el viento.",
    duels: [
      "Un caravanero cubierto de polvo levanta la mano: «El oasis tiene dueños. Convénceme con los ojos.»",
      "Un titiritero te mira entre hilos invisibles: «Cada paso tuyo ya estaba tejido.»",
      "El señor de las dunas se alza sobre una duna en llamas de sol: «Si el desierto te acepta, el resto del mundo también.»",
    ],
    outro: "La arena se asienta a tu paso. Alguien dejó un pozo abierto para ti.",
  },
  agua: {
    title: "Capítulo III · La Niebla que Recuerda",
    intro: "Cientos de islas escondidas tras una niebla que no se levanta nunca. Los clanes del hielo, los tiburones y los alquimistas de espejos guardan viejas heridas, y la niebla las recuerda todas.",
    duels: [
      "Un cazador de tiburones sale del agua con una sonrisa: «Hueles a tierra firme. Veamos si flotas.»",
      "Una figura de hielo se forma frente a ti: «Hace siglos que nadie nos mira sin miedo.»",
      "Entre espejos de mercurio aparece la jefa de la niebla: «Pelea con tu reflejo, o con quien quieras. Yo no importo.»",
    ],
    outro: "La niebla se abre un instante y deja ver el siguiente país, lleno de relámpagos.",
  },
  rayo: {
    title: "Capítulo IV · Meseta del Trueno",
    intro: "Por encima de las nubes, las torres pararrayos zumban sin parar. El País del Rayo respeta la disciplina y la velocidad. Aquí un parpadeo de más es una derrota.",
    duels: [
      "Una vigía de las aves rapaces baja en picado: «Te vi llegar hace tres kilómetros. Demuéstrame que no fue fácil.»",
      "Un herrero del yunque golpea el suelo y salta una chispa: «El metal no miente, y tu ojo tampoco debería.»",
      "El comandante del trueno desciende entre rayos: «Si aguantas mi primera descarga, hablamos.»",
    ],
    outro: "El trueno se aleja rodando. En el horizonte, las montañas de roca esperan.",
  },
  tierra: {
    title: "Capítulo V · Corazón de Roca",
    intro: "Las ciudades se tallan dentro de la montaña y el magma corre bajo cada calle. Los ojos de tierra no son rápidos, pero cuando caen, nada los mueve. Prepárate para un combate largo.",
    duels: [
      "Un leñador del oso planta los pies: «Esta montaña la sostengo yo. Empuja si puedes.»",
      "Un minero con ojos de topo golpea el techo y cae polvo: «Aquí abajo no hay a dónde correr.»",
      "La señora de los dragones de tierra emerge del cráter: «Mi aliento funde acero. ¿Y el tuyo?»",
    ],
    outro: "La roca cede y te deja pasar. Más allá del mapa, algo antiguo mira hacia ti.",
  },
  "abismo-celestial": {
    title: "Capítulo VI · Más Allá del Mapa",
    intro: "Fuera de las Cinco Grandes Naciones existen cráteres, santuarios flotantes y ojos que ya no pertenecen a nadie. Los guardianes del vacío no te piden permiso: te ponen a prueba.",
    duels: [
      "Un sacerdote del reloj celestial inclina la cabeza: «El tiempo aquí no corre. Tú sí. Eso te hace débil.»",
      "Un devoto de la Estrella Negra susurra: «Quien mira el vacío termina pareciéndose a él.»",
      "Un guardián de bestias primordiales abre las alas de fuego: «Si el fénix te reconoce, yo también.»",
    ],
    outro: "El vacío se calla. Un camino polvoriento y ruidoso aparece al fondo: el bazar de Tanzaku.",
  },
  "fronteras-libres": {
    title: "Capítulo VII · Bazar de Tanzaku",
    intro: "Después de tanto abismo, un descanso: herreros, boticarios, relojeros y la famosa hermandad de los ojos chafas. Pero ojo: en la frontera hasta lo más torpe resuena por encima de su rango.",
    duels: [
      "Un chafa de posada se pone en guardia, bizco: «No te rías. Mi ojo falla… pero falla con muchas ganas.»",
      "Una boticaria con ojos de oficio te mide con la mirada: «Tengo un remedio para cada orgullo.»",
      "El jefe de la hermandad chafa se sube a una mesa: «¡Hoy los incompletos damos la sorpresa!»",
    ],
    outro: "El bazar te despide con risas y té caliente. Pero al norte, los valles prohibidos empiezan a arder.",
  },
  "hibridaciones-prohibidas": {
    title: "Capítulo VIII · El Octagrama",
    intro: "Aquí se guardan los ojos que nunca debieron nacer: pentagramas de sangre, heptagramas de siete ruinas y el octagrama que borra la materia. Ya no peleas por el archivo. Peleas para que no se rompa.",
    duels: [
      "Un renegado Kishin dibuja un pentagrama en el aire: «Tu corazón latirá a mi ritmo.»",
      "Una hereje del heptagrama cierra los ojos y siete orbes giran a su alrededor: «Te voy a quitar los sentidos de uno en uno.»",
      "El patriarca del octagrama abre su único ojo: «Llegaste muy lejos. Ahora sostén el vacío.»",
    ],
    outro: "El octagrama se apaga. Los ocho países te devuelven la mirada.",
  },
};

export function chapterFor(landId: string): Chapter {
  return (
    CHAPTERS[landId] ?? {
      title: "Capítulo",
      intro: "Un nuevo país abre sus puertas.",
      duels: ["Un rival se planta frente a ti.", "Otro rival aparece.", "El jefe del país te espera."],
      outro: "Sigues adelante.",
    }
  );
}
