export function fold(s: string): string {
  return s.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase();
}

export function shortMove(text: string): string {
  const head = text.split(":")[0]?.trim() || text;
  return head.length > 72 ? `${head.slice(0, 70)}…` : head;
}

export function moveBlurb(text: string): string {
  const i = text.indexOf(":");
  const tail = i >= 0 ? text.slice(i + 1).trim() : text.trim();
  return tail.length > 150 ? `${tail.slice(0, 148)}…` : tail;
}
