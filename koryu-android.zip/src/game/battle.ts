import { familyColor, matchup } from "./elements";
import { BONUS, RACE_DON } from "./logic";
import { STRIKE, STRIKE_FORMS, movesetFor } from "./moves";
import type { Beat, Choice, Combatant, Eye, Fx, Loadout, Move, Side, Snap, Stats, Status } from "./types";

/* ───────────── niveles ───────────── */

export const MAX_LEVEL = 40;

export function levelMul(level: number): number {
  return 0.55 + level * 0.05;
}

export function xpToNext(level: number): number {
  return 18 + level * 8;
}

export function applyXp(level: number, xp: number, gain: number): { level: number; xp: number; ups: number[] } {
  let lv = level;
  let cur = xp + gain;
  const ups: number[] = [];
  while (lv < MAX_LEVEL && cur >= xpToNext(lv)) {
    cur -= xpToNext(lv);
    lv += 1;
    ups.push(lv);
  }
  if (lv >= MAX_LEVEL) cur = 0;
  return { level: lv, xp: cur, ups };
}

export function enemyLevelFor(landIndex: number, fightIndex: number): number {
  return 2 + landIndex * 3 + fightIndex + (fightIndex === 2 ? 1 : 0);
}

export function xpReward(enemyLevel: number, playerLevel: number, boss: boolean): number {
  const gap = Math.max(0.5, Math.min(1.5, 1 + (enemyLevel - playerLevel) * 0.06));
  return Math.round((enemyLevel * 11 + (boss ? 25 : 0)) * gap);
}

/* ───────────── luchadores ───────────── */

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

function applyLoadout(base: Stats, loadout: Loadout | null) {
  const stats = { ...base };
  let hp = 0;
  let chakra = 0;
  let apexOff = 0;
  let lowHpN = 0;
  const ids = loadout ? [loadout.rune, loadout.mark, loadout.scar, loadout.tattoo] : [];
  for (const id of ids) {
    if (!id) continue;
    const b = BONUS[id]?.bonus;
    if (!b) continue;
    if (b.g) stats.g += b.g;
    if (b.p) stats.p += b.p;
    if (b.n) stats.n += b.n;
    if (b.d) stats.d += b.d;
    if (b.r) stats.r += b.r;
    if (b.hp) hp += b.hp;
    if (b.chakra) chakra += b.chakra;
    if (b.apexOff) apexOff += b.apexOff;
    if (b.lowHpN) lowHpN += b.lowHpN;
  }
  stats.g = clamp(stats.g, 1, 140);
  stats.p = clamp(stats.p, 1, 140);
  stats.n = clamp(stats.n, 1, 140);
  stats.r = clamp(stats.r, 1, 140);
  stats.d = clamp(stats.d, 4, 120);
  return { stats, hp, chakra, apexOff, lowHpN };
}

export function makeCombatant(opts: {
  name: string;
  eye: Eye;
  level: number;
  loadout?: Loadout | null;
  raceId?: string | null;
  wild?: boolean;
  boss?: boolean;
  foe?: boolean;
  outMul?: number;
}): Combatant {
  const don = opts.raceId ? RACE_DON[opts.raceId] : undefined;
  const base: Stats = { ...opts.eye.stats };
  if (don?.drain) base.d = clamp(base.d + don.drain, 4, 120);
  const packed = applyLoadout(base, opts.loadout ?? null);
  const lm = levelMul(opts.level);
  const hpMax = Math.round(28 + 5 * opts.level + 0.7 * packed.stats.p * lm + packed.hp + (don?.hp ?? 0));
  const chakraMax = Math.round(40 + (100 - packed.stats.d) * 0.35 + opts.level * 1.2 + packed.chakra);
  return {
    name: opts.name,
    eye: opts.eye,
    family: opts.eye.family,
    level: opts.level,
    stats: packed.stats,
    hp: hpMax,
    hpMax,
    chakra: chakraMax,
    chakraMax,
    moves: movesetFor(opts.eye),
    unlockBoost: opts.foe ? (opts.boss ? 5 : 2) : 0,
    cds: {},
    status: {},
    guard: 0,
    haste: 0,
    evade: false,
    wild: !!opts.wild,
    outMul: opts.outMul ?? 1,
    inGen: don?.inGen ?? 1,
    outGen: don?.outGen ?? 1,
    outNin: don?.outNin ?? 1,
    elemBias: don?.elem ?? null,
    channelPlus: don?.channel ?? 0,
    guardHeal: don?.heal ?? 0,
    apexOff: packed.apexOff,
    lowHpN: packed.lowHpN,
    apexCdCut: don?.apexCd ? 1 : 0,
  };
}

export function isKnown(c: Combatant, m: Move): boolean {
  return m.unlock <= c.level + c.unlockBoost;
}

export function costOf(c: Combatant, m: Move): number {
  return m.slot === "apex" ? Math.max(10, m.cost - c.apexOff) : m.cost;
}

export function canUse(c: Combatant, m: Move): boolean {
  return isKnown(c, m) && (c.cds[m.id] ?? 0) <= 0 && c.chakra >= costOf(c, m);
}

/* ───────────── daño ───────────── */

function atkOf(c: Combatant, m: Move): number {
  const lm = levelMul(c.level);
  const low = c.hp / c.hpMax < 0.4 ? c.lowHpN : 0;
  if (m.school === "nin") return (c.stats.n + low) * lm;
  if (m.school === "gen") return (c.stats.g + low * 0.4) * lm;
  return ((c.stats.p + c.stats.n) / 2) * lm;
}

function defOf(c: Combatant): number {
  return (22 + c.stats.p * 0.62) * levelMul(c.level);
}

export function expectedDamage(actor: Combatant, target: Combatant, m: Move): number {
  if (m.power <= 0) return 0;
  const ratio = clamp(Math.pow(atkOf(actor, m) / defOf(target), 0.7), 0.55, 1.8);
  const mu = m.family === "body" ? 1 : matchup(m.family, target.family).mult;
  const stab = m.family === actor.family ? 1.2 : 1;
  return (15 + 1.1 * actor.level) * (m.power / 55) * ratio * mu * stab;
}

function rollDamage(actor: Combatant, target: Combatant, m: Move, rng: () => number) {
  const mu = m.family === "body" ? { mult: 1, kind: "even" as const } : matchup(m.family, target.family);
  let dmg = expectedDamage(actor, target, m);
  const crit = rng() < 0.06;
  if (crit) dmg *= 1.5;
  dmg *= 0.88 + rng() * 0.12;
  if (m.school === "gen") dmg *= actor.outGen * target.inGen;
  else if (m.school === "nin") dmg *= actor.elemBias && actor.elemBias === m.family ? actor.outNin : Math.max(1, actor.outNin - 0.04);
  dmg *= actor.outMul;
  let wildNote: "low" | "high" | null = null;
  if (actor.wild) {
    const roll = rng();
    if (roll < 0.28) {
      dmg *= 0.55;
      wildNote = "low";
    } else if (roll > 0.72) {
      dmg *= 1.5;
      wildNote = "high";
    }
  }
  return { dmg: Math.max(1, Math.round(dmg)), mu, crit, wildNote };
}

/* ───────────── estado del combate ───────────── */

export type Battle = {
  you: Combatant;
  foe: Combatant;
  turn: number;
  plan: Choice;
  readNext: boolean;
  over: null | "win" | "lose";
};

const STATUS_TURNS: Record<Status, number> = { burn: 4, bleed: 4, poison: 5, stun: 1, slow: 3, blind: 3 };

export const STATUS_LABEL: Record<Status, string> = {
  burn: "Quemado",
  bleed: "Sangrado",
  poison: "Veneno",
  stun: "Aturdido",
  slow: "Lento",
  blind: "Cegado",
};

const STATUS_VERB: Record<Status, string> = {
  burn: "queda ardiendo",
  bleed: "empieza a sangrar",
  poison: "queda envenenado",
  stun: "queda aturdido",
  slow: "se vuelve lento",
  blind: "queda cegado",
};

export function mulberry(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function snapOf(c: Combatant): Snap {
  return { hp: c.hp, chakra: c.chakra, status: { ...c.status }, guard: c.guard, haste: c.haste };
}

export function snapshot(b: { you: Combatant; foe: Combatant }): { you: Snap; foe: Snap } {
  return { you: snapOf(b.you), foe: snapOf(b.foe) };
}

type Ctx = { you: Combatant; foe: Combatant; beats: Beat[]; rng: () => number };

function push(s: Ctx, text: string, extra: Partial<Beat> = {}) {
  s.beats.push({ text, snap: snapshot(s), ...extra });
}

function other(side: Side): Side {
  return side === "you" ? "foe" : "you";
}

function fxFor(m: Move, from: Side, kind?: Fx): Beat["fx"] {
  const self = m.fx === "heal" || m.fx === "guard";
  return { kind: kind ?? m.fx, color: familyColor(m.family), from, to: self ? from : other(from), family: m.family };
}

function applyStatus(s: Ctx, target: Combatant, side: Side, st: Status) {
  target.status[st] = STATUS_TURNS[st];
  push(s, `${target.name} ${STATUS_VERB[st]}.`, { pop: { side, text: STATUS_LABEL[st], tone: "status" }, sfx: "status" });
}

function faintIfDown(s: Ctx, c: Combatant, side: Side) {
  if (c.hp > 0) return;
  push(s, `El dōjutsu de ${c.name} se apaga.`, { faint: side, sfx: side === "foe" ? "win" : "lose" });
}

function attack(s: Ctx, actor: Combatant, target: Combatant, side: Side, m: Move, announce: string, fxKind?: Fx) {
  const tSide = other(side);
  const cost = costOf(actor, m);
  if (cost > 0) actor.chakra = Math.max(0, actor.chakra - cost);
  if (m.cd > 0) actor.cds[m.id] = Math.max(1, m.cd - (m.slot === "apex" ? actor.apexCdCut : 0));
  if (m.slot === "body") actor.chakra = Math.min(actor.chakraMax, actor.chakra + 6);

  push(s, announce, { fx: fxFor(m, side, fxKind), sfx: "ui" });

  if (m.power <= 0) {
    for (const e of m.effects) {
      if (e.kind === "heal") {
        const heal = Math.round((actor.hpMax * e.pct) / 100);
        const real = Math.min(heal, actor.hpMax - actor.hp);
        actor.hp += real;
        push(s, `${actor.name} recupera ${real} de vida.`, { pop: { side, text: `+${real}`, tone: "heal" }, sfx: "heal" });
      }
    }
    return;
  }

  const acc = (m.acc / 100) * (actor.status.blind ? 0.6 : 1) * (target.evade ? 0.75 : 1);
  if (s.rng() > acc) {
    push(s, `${target.name} esquiva el ataque.`, { pop: { side: tSide, text: "Falla", tone: "miss" }, sfx: "miss" });
    return;
  }

  const roll = rollDamage(actor, target, m, s.rng);
  let dmg = roll.dmg;
  let shielded = false;
  if (target.guard > 0) {
    dmg = Math.max(1, Math.round(dmg * (1 - target.guard)));
    target.guard = 0;
    shielded = true;
  }
  target.hp = Math.max(0, target.hp - dmg);

  const bits: string[] = [];
  if (roll.crit) bits.push("¡Golpe crítico!");
  if (roll.mu.kind === "super") bits.push("¡Es muy eficaz!");
  if (roll.mu.kind === "weak") bits.push("No es muy eficaz…");
  if (shielded) bits.push("La guardia amortigua el golpe.");
  if (roll.wildNote === "low") bits.push("El caudal inestable del ojo chafa desfigura el golpe.");
  if (roll.wildNote === "high") bits.push("El caudal inestable del ojo chafa se desborda.");
  bits.push(`${dmg} de daño.`);
  push(s, bits.join(" "), {
    hit: tSide,
    pop: { side: tSide, text: `-${dmg}`, tone: roll.crit ? "crit" : roll.mu.kind === "super" ? "super" : roll.mu.kind === "weak" ? "weak" : "dmg" },
    sfx: roll.crit ? "crit" : roll.mu.kind === "super" ? "super" : roll.mu.kind === "weak" ? "weak" : "hit",
  });

  for (const e of m.effects) {
    if (e.kind === "drain" && actor.hp > 0) {
      const real = Math.min(Math.round((dmg * e.pct) / 100), actor.hpMax - actor.hp);
      if (real > 0) {
        actor.hp += real;
        push(s, `${actor.name} absorbe ${real} de vida.`, { pop: { side, text: `+${real}`, tone: "heal" }, sfx: "heal" });
      }
    }
  }

  if (target.hp <= 0) {
    faintIfDown(s, target, tSide);
    return;
  }

  for (const e of m.effects) {
    if (e.kind === "status" && !target.status[e.status] && s.rng() * 100 < e.chance) applyStatus(s, target, tSide, e.status);
    if (e.kind === "guard") {
      actor.guard = e.pct / 100;
      push(s, `${actor.name} se cubre tras el golpe.`, { fx: { kind: "guard", color: familyColor(m.family), from: side, to: side, family: m.family }, sfx: "heal" });
    }
    if (e.kind === "haste") {
      actor.haste = 3;
      push(s, `${actor.name} se mueve más rápido.`, { pop: { side, text: "Veloz", tone: "status" }, sfx: "status" });
    }
  }
}

function act(s: Ctx, actor: Combatant, target: Combatant, side: Side, choice: Choice) {
  if (actor.hp <= 0 || target.hp <= 0) return;

  if (actor.status.stun) {
    delete actor.status.stun;
    push(s, `${actor.name} está aturdido y no puede moverse.`, { pop: { side, text: "Aturdido", tone: "status" }, sfx: "status" });
    return;
  }
  if (actor.wild && s.rng() < 0.18) {
    push(s, `${actor.name} tropieza con su propio ojo chafa.`, { pop: { side, text: "Tropieza", tone: "miss" }, sfx: "miss" });
    return;
  }

  if (choice.kind === "guard") {
    const gain = 24 + actor.channelPlus;
    const real = Math.min(gain, actor.chakraMax - actor.chakra);
    actor.chakra += real;
    actor.guard = 0.5;
    const heal = actor.guardHeal ? Math.min(actor.guardHeal, actor.hpMax - actor.hp) : 0;
    actor.hp += heal;
    push(s, `${actor.name} canaliza y se cubre. +${real} de chakra${heal ? ` y ${heal} de vida` : ""}.`, {
      fx: { kind: "guard", color: familyColor(actor.family), from: side, to: side, family: actor.family },
      pop: { side, text: `+${real} chakra`, tone: "heal" },
      sfx: "heal",
    });
    return;
  }

  if (choice.kind === "read") {
    actor.chakra = Math.max(0, actor.chakra - 6);
    actor.evade = true;
    push(s, `${actor.name} lee el gesto del rival.`, {
      fx: { kind: "pulse", color: "#fde68a", from: side, to: side, family: "yang" },
      pop: { side, text: "Percibe", tone: "status" },
      sfx: "status",
    });
    return;
  }

  if (choice.kind === "move") {
    const m = actor.moves[choice.index];
    if (m && canUse(actor, m)) {
      attack(s, actor, target, side, m, `${actor.name} usa ${m.name}.`);
      return;
    }
    push(s, `${actor.name} no logra sostener la técnica y golpea.`);
  }

  const form = STRIKE_FORMS[Math.floor(s.rng() * STRIKE_FORMS.length)]!;
  attack(s, actor, target, side, STRIKE, `${actor.name} ${form.verb}.`, form.fx);
}

function speedOf(c: Combatant, rng: () => number): number {
  return c.stats.r * levelMul(c.level) * (c.haste > 0 ? 1.4 : 1) * (c.status.slow ? 0.6 : 1) + rng() * 4;
}

function endOfTurn(s: Ctx) {
  for (const [c, side] of [
    [s.foe, "foe"],
    [s.you, "you"],
  ] as const) {
    if (c.hp <= 0) continue;
    for (const st of ["burn", "bleed", "poison"] as const) {
      if (!c.status[st]) continue;
      const dmg = Math.max(2, Math.round(c.hpMax * (st === "burn" ? 0.07 : 0.06)));
      c.hp = Math.max(0, c.hp - dmg);
      const word = st === "burn" ? "las quemaduras" : st === "bleed" ? "el sangrado" : "el veneno";
      push(s, `${c.name} sufre ${word}. ${dmg} de daño.`, { hit: side, pop: { side, text: `-${dmg}`, tone: "dmg" }, sfx: "hit" });
      if (c.hp <= 0) {
        faintIfDown(s, c, side);
        break;
      }
    }
  }
  for (const [c, side] of [
    [s.foe, "foe"],
    [s.you, "you"],
  ] as const) {
    if (c.hp <= 0) continue;
    for (const st of ["burn", "bleed", "poison", "slow", "blind"] as const) {
      const left = c.status[st];
      if (!left) continue;
      if (left <= 1) {
        delete c.status[st];
        push(s, `${c.name} deja de estar ${STATUS_LABEL[st].toLowerCase()}.`, { pop: { side, text: "Se pasa", tone: "status" } });
      } else c.status[st] = left - 1;
    }
    for (const k of Object.keys(c.cds)) c.cds[k] = Math.max(0, (c.cds[k] ?? 0) - 1);
    c.chakra = Math.min(c.chakraMax, c.chakra + 3);
    c.guard = 0;
    c.evade = false;
    if (c.haste > 0) c.haste -= 1;
  }
}

/* ───────────── IA del rival ───────────── */

export function aiChoose(foe: Combatant, you: Combatant, rng: () => number): Choice {
  const usable = foe.moves.map((m, index) => ({ m, index })).filter(({ m }) => canUse(foe, m));
  if (usable.length === 0) return rng() < 0.55 ? { kind: "guard" } : { kind: "strike" };
  if (foe.wild) {
    const roll = rng();
    if (roll < 0.2) return { kind: "strike" };
    if (roll < 0.3) return { kind: "guard" };
    return { kind: "move", index: usable[Math.floor(rng() * usable.length)]!.index };
  }
  const hurt = foe.hp / foe.hpMax;
  const scored = usable
    .map(({ m, index }) => {
      let score = expectedDamage(foe, you, m) * (m.acc / 100);
      if (m.power <= 0) score = hurt < 0.5 ? 40 : 0;
      for (const e of m.effects) {
        if (e.kind === "status" && !you.status[e.status]) score += e.chance * 0.25;
        if (e.kind === "drain" && hurt < 0.6) score += 8;
      }
      if (m.slot === "apex" && (you.hp / you.hpMax < 0.5 || hurt < 0.4)) score *= 1.3;
      return { index, score: score * (0.85 + rng() * 0.3) };
    })
    .sort((a, b) => b.score - a.score);
  if (foe.chakra < 14 && rng() < 0.35) return { kind: "guard" };
  if (rng() < 0.1) return { kind: "strike" };
  const pick = rng() < 0.78 || scored.length === 1 ? scored[0]! : scored[1]!;
  return { kind: "move", index: pick.index };
}

export function describeChoice(c: Combatant, choice: Choice): string {
  if (choice.kind === "guard") return "Guardia";
  if (choice.kind === "read") return "Percibir";
  if (choice.kind === "strike") return "Golpear";
  return c.moves[choice.index]?.name ?? "Golpear";
}

export function startBattle(you: Combatant, foe: Combatant, rng: () => number): Battle {
  return { you, foe, turn: 1, plan: aiChoose(foe, you, rng), readNext: false, over: null };
}

export function playTurn(prev: Battle, choice: Choice, rng: () => number): { battle: Battle; beats: Beat[] } {
  const b = structuredClone(prev) as Battle;
  const s: Ctx = { you: b.you, foe: b.foe, beats: [], rng };

  let foeChoice = b.plan;
  if (foeChoice.kind === "move") {
    const m = b.foe.moves[foeChoice.index];
    if (!m || !canUse(b.foe, m)) foeChoice = aiChoose(b.foe, b.you, rng);
  }

  const prio = (c: Choice) => (c.kind === "guard" || c.kind === "read" ? 1 : 0);
  let youFirst: boolean;
  if (prio(choice) !== prio(foeChoice)) youFirst = prio(choice) > prio(foeChoice);
  else youFirst = speedOf(b.you, rng) >= speedOf(b.foe, rng);

  const order: [Combatant, Combatant, Side, Choice][] = youFirst
    ? [
        [b.you, b.foe, "you", choice],
        [b.foe, b.you, "foe", foeChoice],
      ]
    : [
        [b.foe, b.you, "foe", foeChoice],
        [b.you, b.foe, "you", choice],
      ];
  for (const [actor, target, side, ch] of order) {
    if (actor.hp <= 0 || target.hp <= 0) break;
    act(s, actor, target, side, ch);
  }
  if (b.you.hp > 0 && b.foe.hp > 0) endOfTurn(s);

  if (b.foe.hp <= 0) b.over = "win";
  else if (b.you.hp <= 0) b.over = "lose";

  if (!b.over) {
    b.turn += 1;
    b.plan = aiChoose(b.foe, b.you, rng);
    b.readNext = choice.kind === "read";
  } else b.readNext = false;

  return { battle: b, beats: s.beats };
}
