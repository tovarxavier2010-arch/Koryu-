let ctx: AudioContext | null = null;

export function unlockAudio() {
  if (typeof window === "undefined") return;
  if (!ctx) ctx = new AudioContext();
  if (ctx.state === "suspended") void ctx.resume();
}

export type BlipKind = "hit" | "crit" | "super" | "weak" | "heal" | "miss" | "status" | "win" | "lose" | "ui" | "levelup";

function tone(freq: number, dur: number, type: OscillatorType, vol: number, to?: number, delay = 0) {
  if (!ctx) return;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  const t0 = ctx.currentTime + delay;
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);
  if (to) osc.frequency.exponentialRampToValueAtTime(to, t0 + dur);
  gain.gain.setValueAtTime(vol, t0);
  gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
}

export function blip(kind: BlipKind) {
  if (!ctx || ctx.state !== "running") return;
  switch (kind) {
    case "hit":
      tone(190, 0.14, "triangle", 0.06, 80);
      break;
    case "weak":
      tone(140, 0.16, "triangle", 0.04, 70);
      break;
    case "super":
      tone(220, 0.12, "sawtooth", 0.05, 70);
      tone(520, 0.18, "square", 0.035, 900, 0.05);
      break;
    case "crit":
      tone(260, 0.1, "sawtooth", 0.06, 60);
      tone(880, 0.2, "square", 0.04, 1300, 0.06);
      break;
    case "heal":
      tone(440, 0.12, "sine", 0.05);
      tone(660, 0.18, "sine", 0.05, undefined, 0.09);
      break;
    case "miss":
      tone(300, 0.16, "sine", 0.03, 150);
      break;
    case "status":
      tone(330, 0.1, "square", 0.025);
      tone(250, 0.14, "square", 0.025, undefined, 0.09);
      break;
    case "win":
      tone(520, 0.12, "sine", 0.05);
      tone(660, 0.12, "sine", 0.05, undefined, 0.12);
      tone(880, 0.25, "sine", 0.05, undefined, 0.24);
      break;
    case "lose":
      tone(160, 0.5, "triangle", 0.06, 60);
      break;
    case "levelup":
      [440, 554, 660, 880].forEach((f, i) => tone(f, 0.16, "square", 0.035, undefined, i * 0.1));
      break;
    default:
      tone(280, 0.1, "sine", 0.03);
  }
}
