import { createFileRoute } from "@tanstack/react-router";
import { KoryuGame } from "@/components/koryu/KoryuGame";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <KoryuGame />;
}
