import "@fontsource/cinzel/600.css";
import "@fontsource/cinzel/800.css";
import "@fontsource/outfit/400.css";
import "@fontsource/outfit/500.css";
import "@fontsource/outfit/600.css";
import "@fontsource/outfit/700.css";
import "./app.css";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { KoryuGame } from "../src/components/koryu/KoryuGame";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <KoryuGame />
  </StrictMode>,
);
