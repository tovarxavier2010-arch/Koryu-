# Ojos del Kōryu en Android

La app es un APK (Capacitor). El juego corre dentro del teléfono, sin servidor ni internet; la partida se guarda en el propio dispositivo.

## Opción 1: GitHub (sin instalar nada en tu PC)
1. Sube esta carpeta a un repositorio de GitHub.
2. Entra a la pestaña **Actions** → **APK de Android** → **Run workflow**.
3. Cuando termine (unos 5 min), descarga `koryu-apk` desde esa ejecución, descomprime y pasa `app-debug.apk` al celular.
4. En el celular permite "instalar apps desconocidas" y abre el archivo.

## Opción 2: Android Studio
```
npm install
npm run android:open
```
Android Studio abre el proyecto: conecta el celular con depuración USB y presiona ▶.

## Opción 3: por consola (necesita JDK 21 y Android SDK)
```
npm install
npm run android:apk
```
El APK queda en `android/app/build/outputs/apk/debug/app-debug.apk`.

Cada vez que cambies el juego en `src/`, vuelve a ejecutar `npm run android:sync` (los comandos de arriba ya lo hacen).
