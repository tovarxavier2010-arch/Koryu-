import { fileURLToPath } from "node:url";
import { defineConfig } from "vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

// Build estático (sin servidor) que Capacitor mete dentro del APK de Android.
export default defineConfig({
  root: "mobile",
  base: "./",
  publicDir: "../public",
  plugins: [tailwindcss(), viteReact()],
  resolve: { alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) } },
  build: { outDir: "../dist-mobile", emptyOutDir: true, target: "es2020" },
});
