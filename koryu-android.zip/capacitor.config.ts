import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "pe.koryu.ojos",
  appName: "Ojos del Kōryu",
  webDir: "dist-mobile",
  backgroundColor: "#0c0b0a",
  android: { backgroundColor: "#0c0b0a" },
};

export default config;
