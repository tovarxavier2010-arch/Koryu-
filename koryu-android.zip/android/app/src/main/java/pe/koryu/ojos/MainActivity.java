package pe.koryu.ojos;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
